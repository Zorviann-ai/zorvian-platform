CAELOMERE — FULL PORTAL (SOURCE)
================================

This is the working application: public site + signed-in Core
(Cora, CRM, specialists, approvals). It is NOT a static HTML page.

The One.com zip is only the brochure website.
This pack is the real portal.

WHAT IS INSIDE
--------------
src/            Portal, public site, Cora, CRM, specialists
migrations/     Database schema
public/         Logo, Cora portrait, site video, Studios pictures
scripts/        Dev helpers
package.json    Node app
onecom/         Optional static brochure (if you still want One.com)

WHAT YOU NEED
-------------
- Node.js 22 or newer
- npm
- An xAI API key if you want Cora and specialists to speak
  (without it, the desk still stores CRM records)

HOW TO RUN ON YOUR COMPUTER
---------------------------
1. Unzip this folder.
2. Open a terminal in the unzipped folder.
3. npm install
4. Copy your keys into a file named .env  (example below)
5. npm run dev
6. Open the address the terminal prints (usually port 8080).

Public site:   /
Client login:  /login
Portal:        /app
Studios:       /lanterna   (Caelomere Studios)

EXAMPLE .env
------------
XAI_API_KEY=your_key_here
BETTER_AUTH_SECRET=change-this-to-a-long-random-string
VITE_AUTH_ENABLED=true

Database: if DATABASE_URL is not set, a local PGLite file is used.
For production Postgres, set DATABASE_URL and run: npm run db:migrate

ONE.COM
-------
One.com static hosting cannot run this portal.
Upload only the brochure (CAELOMERE-ONECOM.zip) there.
Host this portal on a Node host (Railway, Render, a VPS, etc.).

EMAIL
-----
Outbound email is parked. Drafts and approvals work. Nothing is sent yet.

LICENCE / BRAND
---------------
Caelomere and Caelomere Studios. Use your seal in public/brand.
