#!/usr/bin/env bash
set -euo pipefail
cd /workspace

if [[ -f /tmp/caelomere-dev.pid ]]; then
  kill "$(cat /tmp/caelomere-dev.pid)" 2>/dev/null || true
fi
pkill -f "vite dev --host 0.0.0.0 --port 8080" 2>/dev/null || true

if [[ ! -d node_modules ]]; then
  npm install
fi

npm run dev
