CAELOMERE FULL BUILD
====================
Unzip. You should see folder: caelomere/

  src/            Core portal + Caelomere Studios
  migrations/     Database
  public/         Seal, Cora, site, Studios pictures and films
  package.json    Node app
  README.txt      This file

RUN
1. npm install
2. Create .env with XAI_API_KEY and BETTER_AUTH_SECRET
3. npm run dev

/            public site
/login       portal
/app         Cora, CRM
/studios     Caelomere Studios (Alice, Looking-Glass, storytellers)

If you only have a .grok folder, you opened the wrong zip.
