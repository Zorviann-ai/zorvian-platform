import { createFileRoute, Link, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/lanterna")({
  component: Layout,
  head: () => ({
    meta: [
      { title: "Caelomere Studios — books into motion" },
      {
        name: "description",
        content:
          "Caelomere Studios. Public-domain books as illustrated cinema. Any character may tell the story.",
      },
    ],
  }),
});

function Layout() {
  return (
    <div className="lanterna">
      <header className="relative z-20 flex items-center justify-between gap-4 px-5 py-5 md:px-10">
        <Link to="/lanterna" className="flex items-center gap-3">
          <img src="/brand/seal.png" alt="" className="size-9 rounded-full object-cover" />
          <span className="tracking-[0.28em] text-[11px] font-semibold uppercase text-[color:var(--ln-gold)]">
            Caelomere Studios
          </span>
        </Link>
        <nav className="flex items-center gap-5 text-[11px] uppercase tracking-[0.18em] text-[color:var(--ln-muted)]">
          <Link to="/lanterna" className="hover:text-[color:var(--ln-paper)]">
            Library
          </Link>
          <Link to="/lanterna/alice" className="hover:text-[color:var(--ln-paper)]">
            Alice
          </Link>
          <Link to="/lanterna/looking-glass" className="hover:text-[color:var(--ln-paper)]">
            Looking-Glass
          </Link>
          <Link to="/" className="hover:text-[color:var(--ln-paper)]">
            Core
          </Link>
        </nav>
      </header>
      <Outlet />
    </div>
  );
}
