import { createFileRoute, Link } from "@tanstack/react-router";
import { SHELF } from "@/data/library";

export const Route = createFileRoute("/lanterna/")({ component: Library });

function Library() {
  return (
    <main>
      <section className="relative min-h-[88dvh] overflow-hidden">
        <img
          src="/lanterna/library.jpg"
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[color:var(--ln-ink)] via-[color:var(--ln-ink)]/55 to-black/30" />
        <div className="ln-grain" />
        <div className="relative flex min-h-[88dvh] flex-col justify-end px-5 pb-16 md:px-12 md:pb-20">
          <p className="text-[11px] font-semibold uppercase tracking-[0.32em] text-[color:var(--ln-gold)]">
            Caelomere Studios
          </p>
          <h1 className="mt-4 max-w-3xl text-[clamp(2.8rem,8vw,6.4rem)] leading-[0.9]">
            Books, lit until they move.
          </h1>
          <p className="mt-6 max-w-xl text-[17px] leading-7 text-[color:var(--ln-paper)]/80">
            Free-licensed UK works. Read the original. Watch a chapter become a
            short picture. Choose any character to tell it in their own voice.
          </p>
          <Link
            to="/lanterna/alice"
            className="mt-8 inline-flex w-fit items-center gap-3 border border-[color:var(--ln-gold)] px-6 py-3 text-[11px] font-semibold uppercase tracking-[0.2em] text-[color:var(--ln-gold)] hover:bg-[color:var(--ln-gold)] hover:text-[color:var(--ln-ink)]"
          >
            Open Alice →
          </Link>
        </div>
      </section>

      <section className="px-5 py-16 md:px-12">
        <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-[color:var(--ln-gold)]">
          The shelf
        </p>
        <h2 className="mt-3 text-4xl md:text-5xl">Public domain. United Kingdom.</h2>
        <p className="mt-4 max-w-2xl text-sm leading-6 text-[color:var(--ln-muted)]">
          Authors dead more than seventy years. We use the original text, not
          later film designs. Alice is open. The rest of the shelf is being
          illustrated.
        </p>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {SHELF.map((book) => (
            <article
              key={book.slug}
              className="group overflow-hidden border border-[color:var(--ln-gold)]/25 bg-black/30"
            >
              <div className="relative aspect-[16/10] overflow-hidden">
                <img
                  src={book.cover}
                  alt=""
                  className="h-full w-full object-cover transition duration-700 group-hover:scale-[1.04]"
                />
                {book.status === "coming" && (
                  <span className="absolute right-3 top-3 bg-[color:var(--ln-ink)]/80 px-2 py-1 text-[10px] uppercase tracking-[0.16em] text-[color:var(--ln-gold)]">
                    Coming
                  </span>
                )}
              </div>
              <div className="p-5">
                <p className="text-[11px] uppercase tracking-[0.16em] text-[color:var(--ln-gold)]">
                  {book.author} · {book.year}
                </p>
                <h3 className="mt-2 text-2xl leading-tight">{book.title}</h3>
                <p className="mt-3 text-sm leading-6 text-[color:var(--ln-muted)]">{book.blurb}</p>
                {book.status === "open" ? (
                  <Link
                    to={book.slug === "looking-glass" ? "/lanterna/looking-glass" : "/lanterna/alice"}
                    className="mt-4 inline-block text-[11px] font-semibold uppercase tracking-[0.18em] text-[color:var(--ln-gold)]"
                  >
                    Read and watch →
                  </Link>
                ) : (
                  <p className="mt-4 text-[11px] uppercase tracking-[0.16em] text-[color:var(--ln-muted)]">
                    {book.licence}
                  </p>
                )}
              </div>
            </article>
          ))}
        </div>
      </section>

      <footer className="border-t border-[color:var(--ln-gold)]/20 px-5 py-10 text-xs leading-6 text-[color:var(--ln-muted)] md:px-12">
        Caelomere Studios uses Project Gutenberg texts that are public domain in the UK.
        Pictures are original paintings after the book, not copies of any film.
      </footer>
    </main>
  );
}
