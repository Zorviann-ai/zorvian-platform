import { createFileRoute } from "@tanstack/react-router";
import glass from "@/data/looking-glass.json";
import { GLASS_SCENES } from "@/data/library";
import { GLASS_TELLERS } from "@/data/tellers";
import { Cinema } from "@/components/lanterna/cinema";

export const Route = createFileRoute("/lanterna/looking-glass")({
  component: Page,
});

function Page() {
  return <Cinema book={glass} scenes={GLASS_SCENES} tellers={GLASS_TELLERS} />;
}
