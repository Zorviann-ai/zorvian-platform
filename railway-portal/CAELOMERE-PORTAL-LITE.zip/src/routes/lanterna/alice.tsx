import { createFileRoute } from "@tanstack/react-router";
import alice from "@/data/alice.json";
import { ALICE_SCENES } from "@/data/library";
import { ALICE_TELLERS } from "@/data/tellers";
import { Cinema } from "@/components/lanterna/cinema";

export const Route = createFileRoute("/lanterna/alice")({ component: Page });

function Page() {
  return <Cinema book={alice} scenes={ALICE_SCENES} tellers={ALICE_TELLERS} />;
}
