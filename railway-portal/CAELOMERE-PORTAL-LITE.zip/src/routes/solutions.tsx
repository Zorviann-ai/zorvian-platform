import { createFileRoute } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/site-chrome";
import { AGENTS } from "@/lib/agents";

export const Route = createFileRoute("/solutions")({ component: Solutions });

function Solutions() {
  return (
    <div className="min-h-dvh bg-black text-paper">
      <SiteHeader />
      <section className="px-5 pb-10 pt-32 md:px-16 md:pt-40">
        <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-white/45">
          Solutions
        </p>
        <h1 className="mt-6 max-w-4xl font-display text-[clamp(2.4rem,6vw,4.6rem)] leading-[0.95]">
          A secretary, and a specialist for each field.
        </h1>
        <p className="mt-8 max-w-xl text-[15px] leading-7 text-white/55">
          Cora receives the work. Named specialists brief each other on the team
          desk. Humans keep authority.
        </p>
      </section>
      <section className="px-5 pb-24 md:px-16">
        <div className="hidden grid-cols-[0.7fr_1.1fr] border-b border-white/15 pb-4 text-[11px] font-semibold uppercase tracking-[0.2em] text-white/40 md:grid">
          <span>Specialist</span>
          <span>Role</span>
        </div>
        {AGENTS.filter((a) => a.id !== "receptionist").map((a) => (
          <div
            key={a.id}
            className="grid gap-1 border-b border-white/10 py-7 md:grid-cols-[0.7fr_1.1fr] md:items-baseline"
          >
            <h2 className="font-display text-3xl">{a.name}</h2>
            <p className="text-[15px] text-white/55">{a.role}</p>
          </div>
        ))}
      </section>
      <SiteFooter />
    </div>
  );
}
