import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/site-chrome";

export const Route = createFileRoute("/")({ component: Home });

const SERVICES = [
  ["Reception", "Cora listens, speaks, and captures what is known."],
  ["CRM", "Contacts, companies, pipeline — stored against the tenant."],
  ["Work", "Tasks and bookings prepared. Confirmation waits for a person."],
  ["Documents", "Letters and proposals drafted against the record."],
  ["Specialists", "Named AIs brief each other. Modules attach to one core."],
  ["Guardian", "Approvals. Audit. Isolation. Nothing leaves unattended."],
];

function Home() {
  return (
    <div className="min-h-dvh bg-black text-paper">
      <SiteHeader />

      <section className="relative flex min-h-dvh flex-col justify-between overflow-hidden px-5 pb-10 pt-28 md:px-16 md:pb-12">
        <video
          className="pointer-events-none absolute inset-0 h-full w-full object-cover"
          src="/site/hero.mp4"
          autoPlay
          muted
          loop
          playsInline
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/85" />

        <div
          className="pointer-events-none absolute right-6 top-28 hidden md:block lg:right-20"
          style={{ animation: "cae-drift 7s ease-in-out infinite" }}
        >
          <img
            src="/brand/seal.png"
            alt=""
            className="size-[200px] rounded-full object-cover lg:size-[240px]"
            style={{
              animation: "cae-spin 18s linear infinite",
              boxShadow: "0 0 80px rgba(201,162,74,0.28)",
            }}
          />
        </div>

        <div className="relative z-10 max-w-[408px] pt-8">
          <p className="text-[14px] leading-5 text-white/80">
            At Caelomere we believe a business should be able to speak, and the
            work should move. One secretary. Named specialists. Human authority
            where it matters.
          </p>
        </div>

        <div className="relative z-10 flex flex-col items-start justify-between gap-8 md:flex-row md:items-end">
          <h1>
            <span className="block font-display text-[clamp(3rem,10vw,6rem)] italic leading-none text-transparent [-webkit-text-fill-color:transparent] [background-clip:text] [background-image:linear-gradient(90deg,#fff_16%,#4d4d4d_140%)]">
              Intelligence
            </span>
            <span className="mt-1 block font-sans text-[clamp(2.2rem,8vw,5.4rem)] font-light leading-none tracking-tight text-transparent [-webkit-text-fill-color:transparent] [background-clip:text] [background-image:linear-gradient(90deg,#fff_16%,#4d4d4d_140%)]">
              Meets Opportunity
            </span>
          </h1>
          <Link
            to="/contact"
            className="inline-flex shrink-0 items-center gap-3 rounded-full border border-white/40 px-7 py-4 text-[12px] font-semibold uppercase tracking-[0.18em] text-white hover:border-gold hover:text-gold"
          >
            Let’s connect
            <span aria-hidden>→</span>
          </Link>
        </div>
      </section>

      <section className="bg-gradient-to-b from-[#1f1f1f] to-black px-5 py-24 md:px-16 md:py-32">
        <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-white/45">About</p>
        <h2 className="mt-8 max-w-5xl font-display text-[clamp(1.8rem,4.2vw,3.4rem)] leading-[1.2] text-white">
          Caelomere brings AI, automation and human oversight into one intelligent
          operating layer — built to listen, understand, execute and keep business
          moving.
        </h2>
      </section>

      <section className="px-5 pb-8 md:px-16">
        <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-white/45">
          Our service
        </p>
        <h2 className="mt-6 max-w-4xl font-display text-[clamp(1.6rem,3.4vw,2.6rem)] leading-[1.25] text-white/90">
          From reception and communications to CRM, sales, documents, operations
          and specialist workflows — one coordinated intelligent system.
        </h2>
        <div className="mt-16">
          <div className="hidden grid-cols-[1.1fr_1.6fr] border-b border-white/15 pb-4 text-[11px] font-semibold uppercase tracking-[0.2em] text-white/40 md:grid">
            <span>Service</span>
            <span>What it does</span>
          </div>
          {SERVICES.map(([name, body]) => (
            <div
              key={name}
              className="grid gap-2 border-b border-white/10 py-8 md:grid-cols-[1.1fr_1.6fr] md:items-baseline"
            >
              <h3 className="font-display text-3xl text-white md:text-4xl">{name}</h3>
              <p className="max-w-xl text-[15px] leading-7 text-white/55">{body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="grid min-h-[70vh] md:grid-cols-2">
        <div className="relative min-h-[420px]">
          <img
            src="/brand/cora.jpg"
            alt="Cora, Caelomere secretary"
            className="absolute inset-0 h-full w-full object-cover"
          />
        </div>
        <div className="flex flex-col justify-end bg-[#111] px-8 py-16 md:px-16">
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-gold">
            Secretary
          </p>
          <h2 className="mt-4 font-display text-5xl md:text-6xl">Cora</h2>
          <p className="mt-6 max-w-md text-[15px] leading-7 text-white/60">
            She receives the work. She speaks. She briefs specialists and asks
            for approval before anything leaves the company.
          </p>
          <Link
            to="/login"
            className="mt-10 inline-flex w-fit items-center gap-3 text-[12px] font-semibold uppercase tracking-[0.18em] text-gold"
          >
            Enter the portal →
          </Link>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
