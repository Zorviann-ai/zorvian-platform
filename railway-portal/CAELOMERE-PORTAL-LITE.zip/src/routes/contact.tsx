import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { SiteFooter, SiteHeader } from "@/components/site-chrome";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/field";
import { submitPublicEnquiry } from "@/lib/server/crm";

export const Route = createFileRoute("/contact")({ component: Contact });

function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [company, setCompany] = useState("");
  const [message, setMessage] = useState("");
  const [done, setDone] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  return (
    <div className="min-h-dvh bg-black text-paper">
      <SiteHeader />
      <section className="grid gap-16 px-5 pb-24 pt-32 md:grid-cols-2 md:px-16 md:pt-40">
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-white/45">
            Contact
          </p>
          <h1 className="mt-6 font-display text-[clamp(2.6rem,7vw,5rem)] leading-[0.95]">
            Let’s connect.
          </h1>
          <p className="mt-8 max-w-md text-[16px] leading-8 text-white/55">
            Whether you have a question or want to discuss a workspace, write to
            us. Issued client accounts sign in through Client login.
          </p>
          <p className="mt-8">
            <a className="text-gold" href="mailto:hello@caelomere.com">
              hello@caelomere.com
            </a>
          </p>
        </div>
        <form
          className="rounded-none bg-white p-7 text-fg md:p-10"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError("");
            try {
              await submitPublicEnquiry({ data: { name, email, company, message } });
              setDone(true);
            } catch (err) {
              setError(err instanceof Error ? err.message : "Could not send.");
            } finally {
              setBusy(false);
            }
          }}
        >
          {done ? (
            <p className="text-sm leading-relaxed">
              Received. This stores your enquiry. It does not send email until
              that channel is connected.
            </p>
          ) : (
            <>
              <Field label="Name" htmlFor="n">
                <Input id="n" required value={name} onChange={(e) => setName(e.target.value)} />
              </Field>
              <Field label="Email" htmlFor="e">
                <Input id="e" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
              </Field>
              <Field label="Company" htmlFor="c">
                <Input id="c" value={company} onChange={(e) => setCompany(e.target.value)} />
              </Field>
              <Field label="Message" htmlFor="m">
                <Textarea id="m" required value={message} onChange={(e) => setMessage(e.target.value)} />
              </Field>
              {error ? <p className="mb-3 text-sm text-danger">{error}</p> : null}
              <Button type="submit" disabled={busy}>
                {busy ? "Sending…" : "Send"}
              </Button>
            </>
          )}
        </form>
      </section>
      <SiteFooter />
    </div>
  );
}
