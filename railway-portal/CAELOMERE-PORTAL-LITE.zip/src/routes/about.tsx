import { createFileRoute, Link } from "@tanstack/react-router";
import { SiteFooter, SiteHeader } from "@/components/site-chrome";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  return (
    <div className="min-h-dvh bg-black text-paper">
      <SiteHeader />
      <section className="px-5 pb-10 pt-32 md:px-16 md:pt-40">
        <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-white/45">
          About
        </p>
        <h1 className="mt-6 max-w-4xl font-display text-[clamp(2.4rem,6vw,4.6rem)] leading-[0.95]">
          A workforce you can supervise.
        </h1>
      </section>
      <section className="grid gap-16 px-5 pb-28 md:grid-cols-2 md:px-16">
        <p className="max-w-md text-[16px] leading-8 text-white/70">
          Caelomere is an AI operating system for real businesses. It is not
          another chatbot sitting beside your tools. It is the desk: secretary,
          specialists, CRM, documents and audit in one tenant.
        </p>
        <div className="max-w-md space-y-6 text-[16px] leading-8 text-white/55">
          <p>
            Automation without accountability is a liability. Every consequential
            action can be set to draft only, approval required, or — when a
            channel is actually connected — auto execute. Guardian records the
            trail.
          </p>
          <p>
            Industry modules attach to the same core. They share identity, CRM,
            calendar, documents and permissions. They are not separate islands.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center gap-3 pt-4 text-[12px] font-semibold uppercase tracking-[0.18em] text-gold"
          >
            Speak to Caelomere →
          </Link>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
}
