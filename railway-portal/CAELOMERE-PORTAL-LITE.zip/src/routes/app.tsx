import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getDashboard, type Dashboard } from "@/lib/server/workspace";
import { getCrm } from "@/lib/server/crm";
import { AppShell } from "@/components/app/shell";
import {
  WorkspaceProvider,
  type CrmData,
} from "@/components/app/workspace-context";

export const Route = createFileRoute("/app")({
  component: AppLayout,
});

function AppLayout() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [data, setData] = useState<Dashboard | null>(null);
  const [crm, setCrm] = useState<CrmData | null>(null);

  const refresh = useCallback(async () => {
    const [d, c] = await Promise.all([getDashboard(), getCrm()]);
    setData(d);
    setCrm(c);
  }, []);

  useEffect(() => {
    if (!isPending && !user) void navigate({ to: "/login" });
  }, [isPending, user, navigate]);

  useEffect(() => {
    if (user) void refresh();
  }, [user, refresh]);

  if (isPending || !user) {
    return (
      <div className="grid min-h-dvh place-items-center bg-ink text-paper">
        <p className="text-[11px] font-bold uppercase tracking-[0.2em] text-gold">
          Opening workspace
        </p>
      </div>
    );
  }

  return (
    <WorkspaceProvider value={{ data, crm, loading: !data || !crm, refresh }}>
      <AppShell companyName={data?.workspace.companyName ?? "Your business"} />
    </WorkspaceProvider>
  );
}
