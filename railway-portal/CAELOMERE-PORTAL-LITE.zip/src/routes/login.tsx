import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  GROK_PROVIDERS,
  authClient,
  authEnabled,
  grokOAuthEnabled,
  signIn,
} from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Seal } from "@/components/brand";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isPending && user) void navigate({ to: "/app" });
  }, [isPending, user, navigate]);

  async function onEmail(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({
          email,
          password,
          name: name.trim() || email.split("@")[0],
        });
        if (err) throw new Error(err.message || "Could not create the account.");
      } else {
        const { error: err } = await authClient.signIn.email({
          email,
          password,
        });
        if (err) throw new Error(err.message || "The email or password is incorrect.");
      }
      await navigate({ to: "/app" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-dvh place-items-center bg-ink px-5 py-10">
      <div className="w-full max-w-md overflow-hidden rounded-xl bg-paper-2 shadow-soft">
        <div className="flex flex-col items-center border-b-2 border-gold bg-ink px-7 py-8">
          <Seal size={132} />
          <p className="mt-4 text-[10px] font-bold uppercase tracking-[0.18em] text-paper/45">
            Client portal
          </p>
        </div>
        <div className="px-7 py-8">
          <h1 className="font-display text-3xl text-fg">Client access</h1>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            Create a workspace (or sign in) to speak to Cora. Records stay locked to your account.
          </p>

          {grokOAuthEnabled ? (
            <div className="mt-6 space-y-2">
              {GROK_PROVIDERS.map((p) => (
                <Button
                  key={p.providerId}
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() =>
                    signIn(p.providerId, {
                      callbackURL: "/app",
                      errorCallbackURL: "/login",
                    })
                  }
                >
                  Continue with {p.label}
                </Button>
              ))}
            </div>
          ) : null}

          <div className="my-6 flex items-center gap-3 text-[10px] font-bold uppercase tracking-[0.14em] text-muted">
            <span className="h-px flex-1 bg-line" />
            or email
            <span className="h-px flex-1 bg-line" />
          </div>

          <form onSubmit={onEmail}>
            {mode === "up" && (
              <Field label="Your name" htmlFor="name">
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
              </Field>
            )}
            <Field label="Email address" htmlFor="email">
              <Input
                id="email"
                type="email"
                required
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Field>
            <Field label="Password" htmlFor="password">
              <Input
                id="password"
                type="password"
                required
                minLength={8}
                autoComplete={mode === "up" ? "new-password" : "current-password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </Field>
            {error ? (
              <p className="mb-3 text-sm text-danger" role="alert">
                {error}
              </p>
            ) : null}
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "Checking…" : mode === "up" ? "Create workspace" : "Sign in"}
            </Button>
          </form>

          <button
            type="button"
            className="mt-4 text-sm font-semibold text-warn"
            onClick={() => {
              setMode(mode === "up" ? "in" : "up");
              setError("");
            }}
          >
            {mode === "up" ? "Already have access? Sign in" : "Need a workspace? Create one"}
          </button>

          <p className="mt-6 border-t border-line pt-5 text-xs leading-relaxed text-muted">
            For issued client accounts, contact{" "}
            <a className="font-semibold text-warn" href="mailto:hello@caelomere.com">
              hello@caelomere.com
            </a>
            .{" "}
            <Link to="/" className="font-semibold text-fg">
              Back to Caelomere
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
