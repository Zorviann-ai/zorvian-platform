import { createFileRoute } from "@tanstack/react-router";
import { getSql, dbSource } from "@/lib/db";

export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: async () => {
        const started = Date.now();
        try {
          const sql = await getSql();
          await sql.query("select 1 as ok");
          return Response.json(
            {
              ok: true,
              service: "caelomere-portal",
              database: dbSource,
              checks: { database: "ok" },
              responseMs: Date.now() - started,
              time: new Date().toISOString(),
            },
            {
              status: 200,
              headers: { "cache-control": "no-store" },
            },
          );
        } catch (error) {
          console.error("[health] database check failed", error);
          return Response.json(
            {
              ok: false,
              service: "caelomere-portal",
              database: dbSource,
              checks: { database: "failed" },
              responseMs: Date.now() - started,
              time: new Date().toISOString(),
            },
            {
              status: 503,
              headers: { "cache-control": "no-store" },
            },
          );
        }
      },
    },
  },
});
