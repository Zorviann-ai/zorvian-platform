import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useWorkspace } from "@/components/app/workspace-context";
import { AiPanel } from "@/components/app/ai-panel";
import { MODULE_MAP } from "@/lib/modules";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { saveCampaign } from "@/lib/server/crm";

export const Route = createFileRoute("/app/marketing")({ component: Page });

function Page() {
  const { crm, loading, refresh } = useWorkspace();
  const [title, setTitle] = useState("");
  const [channel, setChannel] = useState("linkedin");
  const [body, setBody] = useState("");
  if (loading || !crm) return <p className="text-sm text-muted">Loading marketing…</p>;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Growth</p>
        <h1 className="font-display text-3xl">Marketing & social</h1>
        <p className="mt-1 text-sm text-muted">
          Mara and Soren draft. Publishing is NOT CONNECTED — campaigns queue for approval.
        </p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <AiPanel
          module={MODULE_MAP.marketing}
          onReply={(reply) => setBody(reply)}
        />
        <AiPanel module={MODULE_MAP.social} onReply={(reply) => setBody(reply)} />
      </div>
      <form
        className="rounded-lg border border-line bg-card p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          await saveCampaign({ data: { title, channel, body } });
          setTitle("");
          setBody("");
          await refresh();
        }}
      >
        <h2 className="font-display text-xl">Queue a campaign draft</h2>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <Field label="Title" htmlFor="mt">
            <Input id="mt" required value={title} onChange={(e) => setTitle(e.target.value)} />
          </Field>
          <Field label="Channel" htmlFor="mc">
            <Select id="mc" value={channel} onChange={(e) => setChannel(e.target.value)}>
              <option value="linkedin">LinkedIn</option>
              <option value="email">Email</option>
              <option value="web">Web</option>
              <option value="x">X</option>
            </Select>
          </Field>
        </div>
        <Field label="Copy" htmlFor="mb">
          <Textarea id="mb" required value={body} onChange={(e) => setBody(e.target.value)} />
        </Field>
        <Button type="submit">Save draft + request approval</Button>
      </form>
      <ul className="divide-y divide-line rounded-lg border border-line bg-card">
        {crm.campaigns.map((c) => (
          <li key={c.id} className="px-5 py-4">
            <div className="flex items-center justify-between">
              <strong className="text-sm">{c.title}</strong>
              <Badge>{c.status}</Badge>
            </div>
            <p className="text-xs text-muted">{c.channel}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
