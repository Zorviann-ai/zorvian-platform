import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useWorkspace } from "@/components/app/workspace-context";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { saveInvoice, requestApproval } from "@/lib/server/crm";
import { addTask } from "@/lib/server/workspace";

export const Route = createFileRoute("/app/finance")({ component: Page });

function Page() {
  const { crm, loading, refresh } = useWorkspace();
  const [contactName, setContactName] = useState("");
  const [amountNote, setAmountNote] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [reference, setReference] = useState("");
  if (loading || !crm) return <p className="text-sm text-muted">Loading finance…</p>;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Money</p>
        <h1 className="font-display text-3xl">Finance</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Invoice records persist here. Banking, VAT filing, card payments and accounting software are <strong>NOT CONNECTED</strong>. Amounts are notes, never live balances.
        </p>
      </div>
      <form
        className="grid gap-3 rounded-lg border border-line bg-card p-5 md:grid-cols-2"
        onSubmit={async (e) => {
          e.preventDefault();
          await saveInvoice({ data: { contactName, amountNote, dueDate, reference } });
          setContactName("");
          setAmountNote("");
          setReference("");
          await refresh();
        }}
      >
        <Field label="Customer" htmlFor="fc">
          <Input id="fc" required value={contactName} onChange={(e) => setContactName(e.target.value)} />
        </Field>
        <Field label="Reference" htmlFor="fr">
          <Input id="fr" value={reference} onChange={(e) => setReference(e.target.value)} />
        </Field>
        <Field label="Amount note" htmlFor="fa">
          <Input
            id="fa"
            value={amountNote}
            placeholder="e.g. to be confirmed by accounts"
            onChange={(e) => setAmountNote(e.target.value)}
          />
        </Field>
        <Field label="Due" htmlFor="fd">
          <Input id="fd" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        </Field>
        <Button type="submit">Create draft invoice</Button>
      </form>
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="ghost"
          onClick={async () => {
            await addTask({
              data: {
                title: "Chase invoices marked overdue — confirmation required before contact",
                owner: "Accounts",
                priority: "high",
              },
            });
            await requestApproval({
              data: {
                agent: "finance",
                action: "chase_debtors",
                summary: "Permission to chase overdue invoices",
              },
            });
            await refresh();
          }}
        >
          Prepare overdue chase (approval required)
        </Button>
      </div>
      <ul className="divide-y divide-line rounded-lg border border-line bg-card">
        {crm.invoices.map((inv) => (
          <li key={inv.id} className="flex items-center justify-between px-5 py-4">
            <div>
              <strong className="block text-sm">{inv.contactName}</strong>
              <span className="text-xs text-muted">
                {inv.reference || "No reference"} · {inv.amountNote || "Amount not set"} · {inv.dueDate || "No due date"}
              </span>
            </div>
            <Badge>{inv.status}</Badge>
          </li>
        ))}
        {crm.invoices.length === 0 && (
          <li className="px-5 py-6 text-sm text-muted">No invoices yet.</li>
        )}
      </ul>
    </div>
  );
}
