import { createFileRoute } from "@tanstack/react-router";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { useWorkspace } from "@/components/app/workspace-context";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/app/settings")({ component: Page });

function Page() {
  const user = useCurrentUser();
  const { data } = useWorkspace();

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Workspace</p>
        <h1 className="font-display text-3xl">Settings</h1>
      </div>
      <section className="rounded-lg border border-line bg-card p-5">
        <h2 className="font-display text-xl">Account</h2>
        <dl className="mt-3 grid gap-2 text-sm">
          <div>
            <dt className="text-[10px] font-bold uppercase tracking-wider text-muted">Signed in as</dt>
            <dd>{user?.primaryEmail ?? user?.displayName ?? "Unknown"}</dd>
          </div>
          <div>
            <dt className="text-[10px] font-bold uppercase tracking-wider text-muted">Company</dt>
            <dd>{data?.workspace.companyName ?? "—"}</dd>
          </div>
        </dl>
      </section>
      <section className="rounded-lg border border-line bg-card p-5">
        <h2 className="font-display text-xl">Integration register</h2>
        <p className="mt-1 text-sm text-muted">Honest statuses only.</p>
        <ul className="mt-4 divide-y divide-line">
          {[
            ["xAI language model", "CONNECTED & TESTED", "Cora and specialists, user-initiated."],
            ["xAI voice", "CONFIGURED BUT UNVERIFIED", "TTS used when you unmute Cora."],
            ["Database", "CONNECTED & TESTED", "Per-workspace records."],
            ["Authentication", "CONNECTED & TESTED", "Email/password, Google, X."],
            ["Email send", "NOT CONNECTED", "Drafts only."],
            ["WhatsApp", "NOT CONNECTED", "Drafts only."],
            ["SMS", "NOT CONNECTED", "Drafts only."],
            ["Telephony", "NOT CONNECTED", "No inbound/outbound calls."],
            ["Payments / banking", "NOT CONNECTED", "Invoice notes only."],
            ["Maps / live traffic", "NOT CONNECTED", "Route plans are operating briefs."],
            ["Social publishing", "NOT CONNECTED", "Campaigns queue for approval."],
            ["Accounting software", "NOT CONNECTED", "No VAT or ledger sync."],
          ].map(([n, s, d]) => (
            <li key={n} className="flex items-start justify-between gap-3 py-3">
              <div>
                <strong className="block text-sm">{n}</strong>
                <span className="text-xs text-muted">{d}</span>
              </div>
              <Badge
                tone={
                  s.startsWith("CONNECTED") ? "live" : s.startsWith("CONFIGURED") ? "build" : "neutral"
                }
              >
                {s}
              </Badge>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
