import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Secretary } from "@/components/app/secretary";
import { PageTitle, PortalCard, StatCard } from "@/components/app/page-title";
import { useWorkspace } from "@/components/app/workspace-context";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { seedWorkspace } from "@/lib/server/workspace";
import { agentFor } from "@/lib/agents";
import { PIPELINE } from "@/lib/server/crm";

export const Route = createFileRoute("/app/")({ component: Home });

function Home() {
  const { data, crm, loading, refresh } = useWorkspace();
  const [seeding, setSeeding] = useState(false);
  if (loading || !data || !crm) {
    return <p className="text-sm text-muted">Loading the desk…</p>;
  }

  const openHandoffs = crm.handoffs.filter((h) => h.status === "open");
  const pending = crm.approvals.filter((a) => a.status === "pending");
  const openTasks = data.tasks.filter((t) => t.status === "open");
  const maxDeals = Math.max(1, ...PIPELINE.map((s) => crm.deals.filter((d) => d.stage === s).length));

  return (
    <div>
      <PageTitle
        title="Dashboard"
        action={
          <Link to="/app/work" className="text-xs font-semibold text-warn">
            + Add task
          </Link>
        }
      />

      {!data.workspace.seeded && (
        <div className="mb-5 flex flex-col gap-3 rounded-md border border-gold/40 bg-gold/10 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <strong className="block text-sm">Load a sample company</strong>
            <p className="text-xs text-muted">
              Northline Plant & Transport — so the widgets are not empty while you try the desk.
            </p>
          </div>
          <Button
            type="button"
            disabled={seeding}
            onClick={async () => {
              setSeeding(true);
              try {
                await seedWorkspace();
                await refresh();
              } finally {
                setSeeding(false);
              }
            }}
          >
            {seeding ? "Loading…" : "Load sample data"}
          </Button>
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Contacts" value={String(data.counts.contacts)} hint="People on the tenant" />
        <StatCard label="Companies" value={String(crm.companies.length)} hint="Accounts on file" />
        <StatCard
          label="Open tasks"
          value={String(openTasks.length)}
          hint={`${data.tasks.length} total`}
        />
        <StatCard
          label="Approvals"
          value={String(pending.length)}
          hint={pending.length ? "Needs a person" : "Clear"}
        />
      </div>

      <div className="mt-5 overflow-hidden rounded-md border border-[#ebe6dc] bg-ink text-paper shadow-[0_0_20px_rgba(10,10,10,0.04)]">
        <Secretary onRefresh={refresh} />
      </div>

      <div className="mt-5 grid gap-4 xl:grid-cols-[1.6fr_1fr]">
        <PortalCard title="Pipeline overview">
          {crm.deals.length === 0 ? (
            <p className="text-sm text-muted">No deals yet. Add them in CRM.</p>
          ) : (
            <ul className="space-y-3">
              {PIPELINE.map((stage) => {
                const n = crm.deals.filter((d) => d.stage === stage).length;
                const w = Math.round((n / maxDeals) * 100);
                return (
                  <li key={stage}>
                    <div className="mb-1 flex justify-between text-xs">
                      <span className="capitalize">{stage}</span>
                      <span className="tabular-nums text-muted">{n}</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-[#f3efe6]">
                      <div className="h-full rounded-full bg-gold" style={{ width: `${w}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
          <div className="mt-4 grid grid-cols-3 border-t border-[#f0ebe3] pt-3 text-center text-xs">
            <div>
              <strong className="block text-base">{crm.deals.length}</strong>
              Deals
            </div>
            <div>
              <strong className="block text-base text-warn">{openTasks.length}</strong>
              Active work
            </div>
            <div>
              <strong className="block text-base">{data.bookings.length}</strong>
              Bookings
            </div>
          </div>
        </PortalCard>

        <PortalCard
          title="Needs a person"
          action={
            <Link to="/app/approvals" className="text-[11px] font-bold uppercase tracking-wider text-warn">
              Open
            </Link>
          }
        >
          {pending.length === 0 ? (
            <p className="text-sm text-muted">No pending approvals.</p>
          ) : (
            <ul className="divide-y divide-[#f0ebe3]">
              {pending.slice(0, 6).map((a) => (
                <li key={a.id} className="py-2.5">
                  <strong className="block text-sm">{a.summary}</strong>
                  <span className="text-xs text-muted">
                    {a.agent} · {a.action}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </PortalCard>
      </div>

      <div className="mt-5 grid gap-4 xl:grid-cols-2">
        <PortalCard
          title="Recent contacts"
          action={
            <Link to="/app/crm" className="text-[11px] font-bold uppercase tracking-wider text-warn">
              CRM
            </Link>
          }
        >
          {data.contacts.length === 0 ? (
            <p className="text-sm text-muted">No contacts yet.</p>
          ) : (
            <table className="w-full text-left text-sm">
              <thead className="text-[11px] uppercase tracking-wider text-muted">
                <tr>
                  <th className="pb-2 font-semibold">Name</th>
                  <th className="pb-2 font-semibold">Company</th>
                  <th className="pb-2 font-semibold">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f0ebe3]">
                {data.contacts.slice(0, 6).map((c) => (
                  <tr key={c.id}>
                    <td className="py-2.5 font-medium">{c.name}</td>
                    <td className="py-2.5 text-muted">{c.company || "—"}</td>
                    <td className="py-2.5">
                      <Badge>{c.status}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </PortalCard>

        <PortalCard title="Team desk" action={<Badge tone="build">{openHandoffs.length} open</Badge>}>
          {crm.handoffs.length === 0 ? (
            <p className="text-sm text-muted">Specialists brief each other here.</p>
          ) : (
            <ul className="divide-y divide-[#f0ebe3]">
              {crm.handoffs.slice(0, 6).map((h) => (
                <li key={h.id} className="flex items-start justify-between gap-3 py-2.5">
                  <div>
                    <strong className="block text-sm">{h.subject}</strong>
                    <span className="text-xs text-muted">
                      {agentFor(h.fromAgent).name} → {agentFor(h.toAgent).name}
                    </span>
                  </div>
                  <Badge tone={h.status === "open" ? "build" : "neutral"}>{h.status}</Badge>
                </li>
              ))}
            </ul>
          )}
        </PortalCard>
      </div>
    </div>
  );
}
