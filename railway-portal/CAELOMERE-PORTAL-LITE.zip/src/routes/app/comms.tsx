import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useWorkspace } from "@/components/app/workspace-context";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { requestApproval } from "@/lib/server/crm";
import { saveDocument } from "@/lib/server/workspace";

export const Route = createFileRoute("/app/comms")({ component: Page });

const CHANNELS = [
  { id: "email", label: "Email", status: "NOT CONNECTED" },
  { id: "whatsapp", label: "WhatsApp", status: "NOT CONNECTED" },
  { id: "sms", label: "SMS", status: "NOT CONNECTED" },
  { id: "telephone", label: "Telephone / calls", status: "NOT CONNECTED" },
] as const;

function Page() {
  const { refresh } = useWorkspace();
  const [channel, setChannel] = useState("email");
  const [to, setTo] = useState("");
  const [body, setBody] = useState("");
  const [saved, setSaved] = useState("");

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Channels</p>
        <h1 className="font-display text-3xl">Communications</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Cora can draft. Nothing is sent from this workspace until a real provider is connected and tested.
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {CHANNELS.map((c) => (
          <article key={c.id} className="rounded-lg border border-line bg-card p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg">{c.label}</h2>
              <Badge>{c.status}</Badge>
            </div>
            <p className="mt-2 text-sm text-muted">
              Drafts can be stored and queued for approval. Live send is blocked.
            </p>
          </article>
        ))}
      </div>
      <form
        className="rounded-lg border border-line bg-card p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          await saveDocument({
            data: {
              type: "Correspondence",
              title: `${channel} draft to ${to}`,
              body,
            },
          });
          await requestApproval({
            data: {
              agent: "secretary",
              action: "send_" + channel,
              summary: `Send ${channel} to ${to}`,
              payload: JSON.stringify({ to, channel, body: body.slice(0, 2000) }),
            },
          });
          setSaved("Draft stored. Approval requested. Message was not sent — email is parked.");
          setBody("");
          await refresh();
        }}
      >
        <h2 className="font-display text-xl">Draft a message</h2>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <Field label="Channel" htmlFor="ch">
            <Select id="ch" value={channel} onChange={(e) => setChannel(e.target.value)}>
              {CHANNELS.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </Select>
          </Field>
          <Field label="To" htmlFor="to">
            <Input id="to" required value={to} onChange={(e) => setTo(e.target.value)} />
          </Field>
        </div>
        <Field label="Message" htmlFor="msg">
          <Textarea id="msg" required value={body} onChange={(e) => setBody(e.target.value)} />
        </Field>
        <Button type="submit">Save draft + request send approval</Button>
        {saved ? <p className="mt-3 text-sm text-success">{saved}</p> : null}
      </form>
    </div>
  );
}
