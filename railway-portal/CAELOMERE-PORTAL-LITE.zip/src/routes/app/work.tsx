import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useWorkspace } from "@/components/app/workspace-context";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import {
  addBooking,
  addTask,
  setBookingStatus,
  setTaskStatus,
} from "@/lib/server/workspace";

export const Route = createFileRoute("/app/work")({ component: WorkPage });

function WorkPage() {
  const { data, loading, refresh } = useWorkspace();
  const [tab, setTab] = useState<"tasks" | "calendar" | "bookings">("tasks");
  if (loading || !data) return <p className="text-sm text-muted">Loading work…</p>;

  return (
    <div>
      <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Operations</p>
      <h1 className="font-display text-3xl">Work</h1>
      <div className="mt-5 flex gap-2">
        {(["tasks", "calendar", "bookings"] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={
              tab === t
                ? "rounded-full bg-ink px-4 py-2 text-xs font-bold uppercase tracking-wider text-paper"
                : "rounded-full border border-line px-4 py-2 text-xs font-bold uppercase tracking-wider text-muted"
            }
          >
            {t}
          </button>
        ))}
      </div>
      {tab === "tasks" && <Tasks data={data} refresh={refresh} />}
      {tab === "calendar" && <Calendar data={data} refresh={refresh} />}
      {tab === "bookings" && <Bookings data={data} refresh={refresh} />}
    </div>
  );
}

function Tasks({
  data,
  refresh,
}: {
  data: NonNullable<ReturnType<typeof useWorkspace>["data"]>;
  refresh: () => Promise<void>;
}) {
  const [title, setTitle] = useState("");
  const [owner, setOwner] = useState("Team");
  const [dueDate, setDueDate] = useState("");
  return (
    <div className="mt-6 rounded-lg border border-line bg-card p-4">
      <form
        className="grid gap-3 md:grid-cols-4"
        onSubmit={async (e) => {
          e.preventDefault();
          await addTask({ data: { title, owner, dueDate } });
          setTitle("");
          await refresh();
        }}
      >
        <Field label="Task" htmlFor="t">
          <Input id="t" required value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="Owner" htmlFor="o">
          <Input id="o" value={owner} onChange={(e) => setOwner(e.target.value)} />
        </Field>
        <Field label="Due" htmlFor="d">
          <Input id="d" type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        </Field>
        <div className="flex items-end">
          <Button type="submit">Add task</Button>
        </div>
      </form>
      <ul className="mt-4 divide-y divide-line">
        {data.tasks.map((t) => (
          <li key={t.id} className="flex items-center justify-between gap-3 py-3">
            <label className="flex items-start gap-3 text-sm">
              <input
                type="checkbox"
                checked={t.status === "done"}
                onChange={async () => {
                  await setTaskStatus({
                    data: { id: t.id, status: t.status === "done" ? "open" : "done" },
                  });
                  await refresh();
                }}
              />
              <span>
                <strong className="block">{t.title}</strong>
                <span className="text-xs text-muted">
                  {t.owner} {t.dueDate ? `· ${t.dueDate}` : ""}
                </span>
              </span>
            </label>
            <Badge tone={t.status === "open" ? "build" : "live"}>{t.status}</Badge>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Calendar({
  data,
}: {
  data: NonNullable<ReturnType<typeof useWorkspace>["data"]>;
  refresh: () => Promise<void>;
}) {
  const events = [...data.bookings].sort((a, b) => `${a.date}${a.time}`.localeCompare(`${b.date}${b.time}`));
  return (
    <div className="mt-6 rounded-lg border border-line bg-card p-4">
      <p className="text-sm text-muted">
        Diary is built from prepared bookings. Nothing is published to an external calendar — Google/Outlook remain NOT CONNECTED.
      </p>
      <ul className="mt-4 divide-y divide-line">
        {events.map((b) => (
          <li key={b.id} className="py-3">
            <strong className="block text-sm">
              {b.date} · {b.time} · {b.contactName}
            </strong>
            <span className="text-xs text-muted">
              {b.type} · {b.status}
            </span>
          </li>
        ))}
        {events.length === 0 && <li className="py-6 text-sm text-muted">No appointments yet.</li>}
      </ul>
    </div>
  );
}

function Bookings({
  data,
  refresh,
}: {
  data: NonNullable<ReturnType<typeof useWorkspace>["data"]>;
  refresh: () => Promise<void>;
}) {
  const [contactName, setContactName] = useState("");
  const [type, setType] = useState("Appointment");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("10:00");
  return (
    <div className="mt-6 rounded-lg border border-line bg-card p-4">
      <form
        className="grid gap-3 md:grid-cols-4"
        onSubmit={async (e) => {
          e.preventDefault();
          await addBooking({ data: { contactName, type, date, time } });
          setContactName("");
          await refresh();
        }}
      >
        <Field label="Who" htmlFor="b-who">
          <Input id="b-who" required value={contactName} onChange={(e) => setContactName(e.target.value)} />
        </Field>
        <Field label="Type" htmlFor="b-ty">
          <Input id="b-ty" value={type} onChange={(e) => setType(e.target.value)} />
        </Field>
        <Field label="Date" htmlFor="b-d">
          <Input id="b-d" type="date" required value={date} onChange={(e) => setDate(e.target.value)} />
        </Field>
        <Field label="Time" htmlFor="b-t">
          <Input id="b-t" type="time" required value={time} onChange={(e) => setTime(e.target.value)} />
        </Field>
        <Button type="submit">Prepare booking</Button>
      </form>
      <p className="mt-2 text-xs text-muted">
        Bookings stay pending until a person confirms. Confirmation messages are NOT CONNECTED.
      </p>
      <ul className="mt-4 divide-y divide-line">
        {data.bookings.map((b) => (
          <li key={b.id} className="flex items-center justify-between gap-3 py-3">
            <div>
              <strong className="block text-sm">{b.contactName}</strong>
              <span className="text-xs text-muted">
                {b.type} · {b.date} {b.time}
              </span>
            </div>
            <Select
              className="w-36"
              value={b.status}
              onChange={async (e) => {
                await setBookingStatus({
                  data: {
                    id: b.id,
                    status: e.target.value as "pending" | "confirmed" | "cancelled",
                  },
                });
                await refresh();
              }}
            >
              <option value="pending">pending</option>
              <option value="confirmed">confirmed</option>
              <option value="cancelled">cancelled</option>
            </Select>
          </li>
        ))}
      </ul>
    </div>
  );
}
