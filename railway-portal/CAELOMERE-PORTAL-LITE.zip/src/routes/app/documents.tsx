import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useWorkspace } from "@/components/app/workspace-context";
import { AiPanel } from "@/components/app/ai-panel";
import { MODULE_MAP } from "@/lib/modules";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { saveDocument } from "@/lib/server/workspace";

export const Route = createFileRoute("/app/documents")({ component: Page });

function Page() {
  const { data, loading, refresh } = useWorkspace();
  const [title, setTitle] = useState("");
  const [type, setType] = useState("Letter");
  const [body, setBody] = useState("");
  const [draft, setDraft] = useState("");
  if (loading || !data) return <p className="text-sm text-muted">Loading documents…</p>;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Studio</p>
        <h1 className="font-display text-3xl">Documents</h1>
        <p className="mt-1 text-sm text-muted">
          Drafts only until a person issues them. Dorian prepares; Guardian records.
        </p>
      </div>
      <AiPanel
        module={MODULE_MAP.documents}
        onReply={(reply) => {
          setDraft(reply);
          setBody(reply);
        }}
      />
      <form
        className="rounded-lg border border-line bg-card p-5"
        onSubmit={async (e) => {
          e.preventDefault();
          await saveDocument({ data: { type, title, body } });
          setTitle("");
          setBody("");
          await refresh();
        }}
      >
        <h2 className="font-display text-xl">Save a draft</h2>
        <div className="mt-3 grid gap-3 md:grid-cols-2">
          <Field label="Title" htmlFor="dt">
            <Input id="dt" required value={title} onChange={(e) => setTitle(e.target.value)} />
          </Field>
          <Field label="Type" htmlFor="dy">
            <Select id="dy" value={type} onChange={(e) => setType(e.target.value)}>
              {["Letter", "Proposal", "Contract", "Report", "Tender", "Form"].map((t) => (
                <option key={t}>{t}</option>
              ))}
            </Select>
          </Field>
        </div>
        <Field label="Body" htmlFor="db">
          <Textarea id="db" required value={body} onChange={(e) => setBody(e.target.value)} />
        </Field>
        <Button type="submit">Save draft</Button>
        {draft && (
          <p className="mt-2 text-xs text-muted">Latest specialist draft loaded into the form.</p>
        )}
      </form>
      <ul className="divide-y divide-line rounded-lg border border-line bg-card">
        {data.documents.map((d) => (
          <li key={d.id} className="px-5 py-4">
            <div className="flex items-center justify-between">
              <strong className="text-sm">{d.title}</strong>
              <Badge>{d.status}</Badge>
            </div>
            <p className="mt-1 text-xs text-muted">{d.type}</p>
            <pre className="mt-2 max-h-32 overflow-auto whitespace-pre-wrap text-xs text-muted">
              {d.body.slice(0, 600)}
            </pre>
          </li>
        ))}
        {data.documents.length === 0 && (
          <li className="px-5 py-6 text-sm text-muted">No documents yet.</li>
        )}
      </ul>
    </div>
  );
}
