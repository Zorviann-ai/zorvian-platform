import { createFileRoute, Link } from "@tanstack/react-router";
import { useWorkspace } from "@/components/app/workspace-context";
import { AiPanel } from "@/components/app/ai-panel";
import { MODULE_MAP, isModuleId } from "@/lib/modules";
import { agentFor } from "@/lib/agents";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { setHandoffStatus } from "@/lib/server/crm";

export const Route = createFileRoute("/app/team/$module")({ component: Page });

function Page() {
  const { module } = Route.useParams();
  const { crm, loading, refresh } = useWorkspace();
  if (!isModuleId(module)) {
    return (
      <p className="text-sm text-muted">
        Unknown specialist. <Link to="/app">Return home</Link>
      </p>
    );
  }
  const def = MODULE_MAP[module];
  const agent = agentFor(module);
  const inbox = crm?.handoffs.filter((h) => h.toAgent === module || h.fromAgent === module) ?? [];

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">
          {agent.role}
        </p>
        <h1 className="font-display text-3xl">{agent.name}</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">{def.desc}</p>
      </div>
      {loading ? null : (
        <div className="rounded-lg border border-line bg-card p-4">
          <h2 className="font-display text-lg">Inbox from the team</h2>
          {inbox.length === 0 ? (
            <p className="mt-2 text-sm text-muted">No briefs yet.</p>
          ) : (
            <ul className="mt-2 divide-y divide-line">
              {inbox.slice(0, 8).map((h) => (
                <li key={h.id} className="flex items-start justify-between gap-3 py-3">
                  <div>
                    <strong className="block text-sm">{h.subject}</strong>
                    <span className="text-xs text-muted">
                      {agentFor(h.fromAgent).name} → {agentFor(h.toAgent).name}
                    </span>
                    {h.body ? (
                      <p className="mt-1 line-clamp-3 text-xs text-muted">{h.body}</p>
                    ) : null}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge>{h.status}</Badge>
                    {h.status === "open" && (
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={async () => {
                          await setHandoffStatus({ data: { id: h.id, status: "done" } });
                          await refresh();
                        }}
                      >
                        Mark seen
                      </Button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
      <AiPanel module={def} onReply={() => void refresh()} />
    </div>
  );
}
