import { createFileRoute } from "@tanstack/react-router";
import { useWorkspace } from "@/components/app/workspace-context";
import { Badge } from "@/components/ui/badge";
import { formatWhen } from "@/lib/utils";

export const Route = createFileRoute("/app/guardian")({ component: Page });

function Page() {
  const { data, loading } = useWorkspace();
  if (loading || !data) return <p className="text-sm text-muted">Loading Guardian…</p>;

  return (
    <div className="space-y-6">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Security</p>
        <h1 className="font-display text-3xl">Guardian</h1>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Tenant isolation is enforced by authenticated user id on every record. API keys never leave the server.
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-3">
        {[
          ["Authentication", "Live", "Email/password plus Google and X via the platform broker."],
          ["Tenant separation", "Live", "Every query is scoped to the signed-in workspace."],
          ["Audit trail", "Live", "Creates, AI runs, approvals and bookings are recorded."],
          ["MFA", "NOT CONNECTED", "Platform broker may add it later — not configured here."],
          ["Rate limiting", "PARTIAL", "AI calls are user-initiated and token-capped."],
          ["Backup", "PARTIAL", "Database is platform-managed. No separate restore console yet."],
        ].map(([t, s, d]) => (
          <article key={t} className="rounded-lg border border-line bg-card p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg">{t}</h2>
              <Badge tone={s === "Live" ? "live" : s === "PARTIAL" ? "build" : "neutral"}>{s}</Badge>
            </div>
            <p className="mt-2 text-sm text-muted">{d}</p>
          </article>
        ))}
      </div>
      <div className="rounded-lg border border-line bg-card">
        <h2 className="border-b border-line px-5 py-3 font-display text-lg">Audit</h2>
        <ul className="divide-y divide-line">
          {data.audit.map((e) => (
            <li key={e.id} className="px-5 py-3">
              <strong className="block text-sm">{e.event}</strong>
              <span className="text-xs text-muted">
                {formatWhen(e.createdAt)} · {e.detail}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
