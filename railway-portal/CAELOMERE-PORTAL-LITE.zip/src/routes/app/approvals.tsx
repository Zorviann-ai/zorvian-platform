import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useWorkspace } from "@/components/app/workspace-context";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { decideApproval } from "@/lib/server/crm";
import { formatWhen } from "@/lib/utils";

export const Route = createFileRoute("/app/approvals")({ component: Page });

function Page() {
  const { crm, loading, refresh } = useWorkspace();
  const [note, setNote] = useState("");
  if (loading || !crm) return <p className="text-sm text-muted">Loading approvals…</p>;

  return (
    <div>
      <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold-2">Control</p>
      <h1 className="font-display text-3xl">Approvals</h1>
      <p className="mt-1 max-w-2xl text-sm text-muted">
        Approve changes the record on the desk (booking confirmed, document ready, campaign held or released).
        Email, SMS and WhatsApp stay parked — nothing leaves the company from here yet.
      </p>
      {note ? <p className="mt-3 text-sm text-gold">{note}</p> : null}
      <ul className="mt-6 divide-y divide-line rounded-lg border border-line bg-card">
        {crm.approvals.map((a) => (
          <li key={a.id} className="flex flex-col gap-3 px-5 py-4 md:flex-row md:items-center md:justify-between">
            <div>
              <strong className="block text-sm">{a.summary}</strong>
              <span className="text-xs text-muted">
                {a.agent} · {a.action} · {formatWhen(a.createdAt)}
              </span>
              {a.result ? <p className="mt-1 text-xs text-muted">{a.result}</p> : null}
            </div>
            <div className="flex items-center gap-2">
              <Badge tone={a.status === "pending" ? "build" : a.status === "approved" ? "live" : "danger"}>
                {a.status}
              </Badge>
              {a.status === "pending" && (
                <>
                  <Button
                    size="sm"
                    onClick={async () => {
                      const r = await decideApproval({ data: { id: a.id, status: "approved" } });
                      setNote("ok" in r && r.ok ? r.result : "Could not approve.");
                      await refresh();
                    }}
                  >
                    Approve
                  </Button>
                  <Button
                    size="sm"
                    variant="danger"
                    onClick={async () => {
                      const r = await decideApproval({ data: { id: a.id, status: "rejected" } });
                      setNote("ok" in r && r.ok ? r.result : "Could not reject.");
                      await refresh();
                    }}
                  >
                    Reject
                  </Button>
                </>
              )}
            </div>
          </li>
        ))}
        {crm.approvals.length === 0 && (
          <li className="px-5 py-6 text-sm text-muted">No approval requests yet.</li>
        )}
      </ul>
    </div>
  );
}