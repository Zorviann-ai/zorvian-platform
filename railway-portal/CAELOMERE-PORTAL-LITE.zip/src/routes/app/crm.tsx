import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useWorkspace } from "@/components/app/workspace-context";
import { PageTitle, PortalCard } from "@/components/app/page-title";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";
import { addContact } from "@/lib/server/workspace";
import {
  PIPELINE,
  deleteCompany,
  deleteContact,
  deleteDeal,
  moveDeal,
  saveCompany,
  saveDeal,
  updateContact,
  addNote,
} from "@/lib/server/crm";

export const Route = createFileRoute("/app/crm")({ component: CrmPage });

type Tab = "contacts" | "companies" | "pipeline";

function CrmPage() {
  const { data, crm, loading, refresh } = useWorkspace();
  const [tab, setTab] = useState<Tab>("contacts");
  const [q, setQ] = useState("");
  if (loading || !data || !crm) return <p className="text-sm text-muted">Loading CRM…</p>;

  return (
    <div>
      <PageTitle title="CRM" />
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1 rounded-md bg-white p-1 shadow-[0_0_20px_rgba(10,10,10,0.04)]">
          {(["contacts", "companies", "pipeline"] as Tab[]).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={
                tab === t
                  ? "rounded-sm bg-ink px-4 py-2 text-xs font-bold uppercase tracking-wider text-paper"
                  : "rounded-sm px-4 py-2 text-xs font-bold uppercase tracking-wider text-muted"
              }
            >
              {t}
            </button>
          ))}
        </div>
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search"
          className="max-w-xs bg-white"
        />
      </div>
      {tab === "contacts" && (
        <Contacts q={q} refresh={refresh} contacts={data.contacts} companies={crm.companies} notes={crm.notes} />
      )}
      {tab === "companies" && <Companies q={q} refresh={refresh} companies={crm.companies} />}
      {tab === "pipeline" && (
        <Pipeline q={q} refresh={refresh} deals={crm.deals} contacts={data.contacts} companies={crm.companies} />
      )}
    </div>
  );
}

function Contacts({
  q,
  refresh,
  contacts,
  companies,
  notes,
}: {
  q: string;
  refresh: () => Promise<void>;
  contacts: {
    id: string;
    name: string;
    company: string | null;
    email: string | null;
    phone: string | null;
    need: string | null;
    status: string;
    score: number;
  }[];
  companies: { id: string; name: string }[];
  notes: { id: string; parentType: string; parentId: string; body: string; createdAt: string }[];
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [need, setNeed] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const filtered = useMemo(
    () =>
      contacts.filter((c) =>
        `${c.name} ${c.company} ${c.email} ${c.need}`.toLowerCase().includes(q.toLowerCase()),
      ),
    [contacts, q],
  );
  const current = contacts.find((c) => c.id === selected);

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
      <PortalCard title="Contacts">
        <form
          className="mb-4 grid gap-3 border-b border-[#f0ebe3] pb-4 md:grid-cols-2"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            try {
              await addContact({ data: { name, email, phone, company, need, source: "CRM" } });
              setName("");
              setEmail("");
              setPhone("");
              setCompany("");
              setNeed("");
              await refresh();
            } finally {
              setBusy(false);
            }
          }}
        >
          <Field label="Name" htmlFor="c-name">
            <Input id="c-name" required value={name} onChange={(e) => setName(e.target.value)} />
          </Field>
          <Field label="Company" htmlFor="c-co">
            <Input id="c-co" value={company} onChange={(e) => setCompany(e.target.value)} />
          </Field>
          <Field label="Email" htmlFor="c-em">
            <Input id="c-em" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          </Field>
          <Field label="Phone" htmlFor="c-ph">
            <Input id="c-ph" value={phone} onChange={(e) => setPhone(e.target.value)} />
          </Field>
          <div className="md:col-span-2">
            <Field label="Need / enquiry" htmlFor="c-need">
              <Input id="c-need" value={need} onChange={(e) => setNeed(e.target.value)} />
            </Field>
            <Button type="submit" disabled={busy}>
              {busy ? "Saving…" : "Add contact"}
            </Button>
          </div>
        </form>
        <table className="w-full text-left text-sm">
          <thead className="text-[11px] uppercase tracking-wider text-muted">
            <tr>
              <th className="pb-2 font-semibold">Name</th>
              <th className="pb-2 font-semibold">Company</th>
              <th className="hidden pb-2 font-semibold sm:table-cell">Email</th>
              <th className="pb-2 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#f0ebe3]">
            {filtered.map((c) => (
              <tr
                key={c.id}
                className="cursor-pointer hover:bg-[#faf7f1]"
                onClick={() => setSelected(c.id)}
              >
                <td className="py-2.5 font-medium">{c.name}</td>
                <td className="py-2.5 text-muted">{c.company || "—"}</td>
                <td className="hidden py-2.5 text-muted sm:table-cell">{c.email || "—"}</td>
                <td className="py-2.5">
                  <Badge>{c.status}</Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <p className="py-6 text-sm text-muted">No contacts match.</p>}
      </PortalCard>
      <PortalCard title={current ? current.name : "Record"}>
        {!current ? (
          <p className="text-sm text-muted">Select a contact to edit, note or delete.</p>
        ) : (
          <ContactEditor
            contact={current}
            companies={companies}
            notes={notes.filter((n) => n.parentType === "contact" && n.parentId === current.id)}
            note={note}
            setNote={setNote}
            onRefresh={refresh}
          />
        )}
      </PortalCard>
    </div>
  );
}

function ContactEditor({
  contact,
  companies,
  notes,
  note,
  setNote,
  onRefresh,
}: {
  contact: {
    id: string;
    name: string;
    company: string | null;
    email: string | null;
    phone: string | null;
    need: string | null;
    status: string;
  };
  companies: { id: string; name: string }[];
  notes: { id: string; body: string; createdAt: string }[];
  note: string;
  setNote: (v: string) => void;
  onRefresh: () => Promise<void>;
}) {
  const [name, setName] = useState(contact.name);
  const [status, setStatus] = useState(contact.status);
  const [need, setNeed] = useState(contact.need ?? "");

  return (
    <div>
      <Field label="Name" htmlFor="e-name">
        <Input id="e-name" value={name} onChange={(e) => setName(e.target.value)} />
      </Field>
      <Field label="Status" htmlFor="e-st">
        <Select id="e-st" value={status} onChange={(e) => setStatus(e.target.value)}>
          {["new", "qualified", "follow-up", "won", "lost"].map((s) => (
            <option key={s}>{s}</option>
          ))}
        </Select>
      </Field>
      <Field label="Need" htmlFor="e-need">
        <Textarea id="e-need" className="min-h-24" value={need} onChange={(e) => setNeed(e.target.value)} />
      </Field>
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          onClick={async () => {
            await updateContact({
              data: {
                id: contact.id,
                name,
                status,
                need,
                company: contact.company ?? undefined,
                email: contact.email ?? undefined,
                phone: contact.phone ?? undefined,
              },
            });
            await onRefresh();
          }}
        >
          Save
        </Button>
        <Button
          type="button"
          variant="danger"
          onClick={async () => {
            await deleteContact({ data: { id: contact.id } });
            await onRefresh();
          }}
        >
          Delete
        </Button>
      </div>
      <form
        className="mt-5 border-t border-[#f0ebe3] pt-4"
        onSubmit={async (e) => {
          e.preventDefault();
          if (!note.trim()) return;
          await addNote({ data: { parentType: "contact", parentId: contact.id, body: note } });
          setNote("");
          await onRefresh();
        }}
      >
        <Field label="Add note" htmlFor="note">
          <Textarea id="note" className="min-h-20" value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
        <Button type="submit" variant="ghost">
          Save note
        </Button>
      </form>
      <ul className="mt-3 space-y-2">
        {notes.map((n) => (
          <li key={n.id} className="rounded-md bg-[#faf7f1] px-3 py-2 text-xs leading-relaxed">
            {n.body}
          </li>
        ))}
      </ul>
      {companies.length > 0 && (
        <p className="mt-4 text-[10px] uppercase tracking-wider text-muted">
          {companies.length} companies on file
        </p>
      )}
    </div>
  );
}

function Companies({
  q,
  refresh,
  companies,
}: {
  q: string;
  refresh: () => Promise<void>;
  companies: {
    id: string;
    name: string;
    industry: string | null;
    email: string | null;
    phone: string | null;
    notes: string | null;
  }[];
}) {
  const [name, setName] = useState("");
  const [industry, setIndustry] = useState("");
  const [email, setEmail] = useState("");
  const filtered = companies.filter((c) => `${c.name} ${c.industry}`.toLowerCase().includes(q.toLowerCase()));
  return (
    <PortalCard title="Companies">
      <form
        className="grid gap-3 md:grid-cols-3"
        onSubmit={async (e) => {
          e.preventDefault();
          await saveCompany({ data: { name, industry, email } });
          setName("");
          setIndustry("");
          setEmail("");
          await refresh();
        }}
      >
        <Field label="Company name" htmlFor="co-n">
          <Input id="co-n" required value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Industry" htmlFor="co-i">
          <Input id="co-i" value={industry} onChange={(e) => setIndustry(e.target.value)} />
        </Field>
        <Field label="Email" htmlFor="co-e">
          <Input id="co-e" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <div>
          <Button type="submit">Add company</Button>
        </div>
      </form>
      <table className="mt-4 w-full text-left text-sm">
        <thead className="text-[11px] uppercase tracking-wider text-muted">
          <tr>
            <th className="pb-2 font-semibold">Name</th>
            <th className="pb-2 font-semibold">Industry</th>
            <th className="pb-2 font-semibold"></th>
          </tr>
        </thead>
        <tbody className="divide-y divide-[#f0ebe3]">
          {filtered.map((c) => (
            <tr key={c.id}>
              <td className="py-2.5 font-medium">{c.name}</td>
              <td className="py-2.5 text-muted">{c.industry || "—"}</td>
              <td className="py-2.5 text-right">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={async () => {
                    await deleteCompany({ data: { id: c.id } });
                    await refresh();
                  }}
                >
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </PortalCard>
  );
}

function Pipeline({
  q,
  refresh,
  deals,
}: {
  q: string;
  refresh: () => Promise<void>;
  deals: { id: string; title: string; stage: string; valueNote: string | null }[];
  contacts: { id: string; name: string }[];
  companies: { id: string; name: string }[];
}) {
  const [title, setTitle] = useState("");
  const [valueNote, setValueNote] = useState("");
  const filtered = deals.filter((d) => d.title.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <PortalCard title="Add to pipeline">
        <form
          className="flex flex-wrap gap-3"
          onSubmit={async (e) => {
            e.preventDefault();
            await saveDeal({ data: { title, valueNote } });
            setTitle("");
            setValueNote("");
            await refresh();
          }}
        >
          <Input required value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Deal title" className="max-w-sm" />
          <Input
            value={valueNote}
            onChange={(e) => setValueNote(e.target.value)}
            placeholder="Value note — never invent a price"
            className="max-w-sm"
          />
          <Button type="submit">Add</Button>
        </form>
      </PortalCard>
      <div className="mt-4 grid gap-3 md:grid-cols-5">
        {PIPELINE.map((stage) => (
          <div key={stage} className="rounded-md border border-[#ebe6dc] bg-white p-3">
            <p className="mb-2 text-[10px] font-bold uppercase tracking-[0.14em] text-muted">{stage}</p>
            {filtered
              .filter((d) => d.stage === stage)
              .map((d) => (
                <article key={d.id} className="mb-2 rounded-md border border-[#f0ebe3] bg-[#faf7f1] p-3">
                  <strong className="block text-sm">{d.title}</strong>
                  <span className="text-xs text-muted">{d.valueNote || "Value not set"}</span>
                  <Select
                    className="mt-2 h-9 text-xs"
                    value={d.stage}
                    onChange={async (e) => {
                      await moveDeal({
                        data: { id: d.id, stage: e.target.value as (typeof PIPELINE)[number] },
                      });
                      await refresh();
                    }}
                  >
                    {PIPELINE.map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </Select>
                  <button
                    type="button"
                    className="mt-2 text-[10px] uppercase tracking-wider text-danger"
                    onClick={async () => {
                      await deleteDeal({ data: { id: d.id } });
                      await refresh();
                    }}
                  >
                    Remove
                  </button>
                </article>
              ))}
          </div>
        ))}
      </div>
    </div>
  );
}
