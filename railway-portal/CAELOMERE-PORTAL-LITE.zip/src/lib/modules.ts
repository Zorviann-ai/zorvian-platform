export type ModuleId =
  | "receptionist"
  | "calendar"
  | "bookings"
  | "leads"
  | "social"
  | "marketing"
  | "support"
  | "quotes"
  | "tasks"
  | "intelligence"
  | "route"
  | "documents"
  | "auto"
  | "freshx"
  | "tenders"
  | "guardian";

export type NavGroup = "workspace" | "operations" | "specialist";

export type ModuleDef = {
  id: ModuleId;
  n: string;
  title: string;
  short: string;
  desc: string;
  group: NavGroup;
  placeholder: string;
  button: string;
  caps: [string, string][];
  presets: string[];
};

export const MODULES: ModuleDef[] = [
  {
    id: "receptionist",
    n: "02",
    title: "AI Receptionist",
    short: "Receptionist",
    desc: "Qualify enquiries, capture requirements and prepare a human handoff.",
    group: "workspace",
    placeholder:
      "Paste a customer enquiry. Example: I need a transport quote for three vehicles next Tuesday.",
    button: "Qualify enquiry",
    caps: [
      ["Qualification", "Identify the need, urgency and missing facts."],
      ["Lead capture", "Write a structured record into your workspace."],
      ["Human handoff", "Flag conversations that need your team."],
      ["No invention", "Never invent prices, availability or bookings."],
    ],
    presets: [
      "Caller wants a same-day appointment but gives no preferred time.",
      "Customer asks for a quote and says it is urgent.",
      "I need a transport quote for three vehicles next Tuesday.",
    ],
  },
  {
    id: "calendar",
    n: "03",
    title: "AI Calendar",
    short: "Calendar",
    desc: "Prepare appointments and organise the working day.",
    group: "workspace",
    placeholder:
      "Example: Arrange a 45 minute site meeting next Tuesday at 10:30 with James Whitaker.",
    button: "Prepare appointment",
    caps: [
      ["Appointment brief", "Extract date, time, duration and attendees."],
      ["Missing information", "Identify what is required before scheduling."],
      ["No false bookings", "Never claim a calendar event was created."],
    ],
    presets: [
      "Arrange a 45 minute meeting next Tuesday at 10:30am with the site manager.",
      "Block Friday afternoon for vehicle inspections at the Manchester depot.",
    ],
  },
  {
    id: "bookings",
    n: "04",
    title: "AI Booking",
    short: "Bookings",
    desc: "Prepare customer bookings and confirmation checklists.",
    group: "workspace",
    placeholder:
      "Example: Customer wants to book a mini excavator for three days starting Monday.",
    button: "Prepare booking",
    caps: [
      ["Requirement capture", "Extract equipment, dates and customer details."],
      ["Checklist", "Identify information still required."],
      ["Confirmation draft", "Prepare a professional confirmation — not a live booking."],
    ],
    presets: [
      "Customer wants to book a mini excavator for three days starting Monday.",
      "Hold a 8-ton excavator for a Manchester groundworks job next week.",
    ],
  },
  {
    id: "leads",
    n: "05",
    title: "AI Leads",
    short: "Leads",
    desc: "Understand buying intent and prioritise follow-up.",
    group: "workspace",
    placeholder: "Paste a customer enquiry, sales note or lead details.",
    button: "Analyse lead",
    caps: [
      ["Buying intent", "How close the customer appears to a decision."],
      ["Priority", "Which opportunities deserve attention first."],
      ["Follow-up", "The next sales action, with missing facts marked."],
    ],
    presets: [
      "Rank these leads: a same-day hire request, a vague website form, and a repeat customer asking for a quote.",
      "Strong engagement on a plant-hire enquiry but no budget or site address given.",
    ],
  },
  {
    id: "social",
    n: "06",
    title: "AI Social",
    short: "Social",
    desc: "Create professional social content with a visual post preview.",
    group: "workspace",
    placeholder:
      "Example: Announce a new 8-ton excavator available for hire in Manchester.",
    button: "Generate social plan",
    caps: [
      ["Visual preview", "See copy and layout together before publishing."],
      ["No emoji clutter", "Professional copy without decorative noise."],
      ["Factual safeguards", "No invented prices, specs or contact details."],
    ],
    presets: [
      "Announce a new 8-ton excavator available for hire at our Manchester depot, suitable for construction and groundwork projects.",
      "LinkedIn post for a transport company that has added two extra long-wheelbase vans.",
    ],
  },
  {
    id: "marketing",
    n: "07",
    title: "AI Marketing",
    short: "Marketing",
    desc: "Plan campaigns, offers and customer communications.",
    group: "workspace",
    placeholder:
      "Example: Create a campaign to generate more local plant hire enquiries.",
    button: "Create marketing plan",
    caps: [
      ["Campaign planning", "Build around a clear commercial objective."],
      ["Audience", "Define the most relevant customer groups."],
      ["Measurement", "Identify useful campaign measures."],
    ],
    presets: [
      "Create a campaign to generate more local plant hire enquiries in Greater Manchester.",
      "Plan a 30-day follow-up sequence for unused quote requests.",
    ],
  },
  {
    id: "support",
    n: "08",
    title: "Customer Support",
    short: "Support",
    desc: "Prepare professional customer responses and escalation.",
    group: "operations",
    placeholder: "Paste the customer's message.",
    button: "Prepare response",
    caps: [
      ["Response draft", "Clear, professional language."],
      ["Urgency", "Issues that need immediate attention."],
      ["Escalation", "When a person should take over."],
    ],
    presets: [
      "The excavator we hired yesterday has a hydraulic leak and the job is standing.",
      "Customer is unhappy that a quote has not arrived after three days.",
    ],
  },
  {
    id: "quotes",
    n: "09",
    title: "Quotes & Sales",
    short: "Quotes",
    desc: "Structure requirements and sales follow-up. Never invent prices.",
    group: "operations",
    placeholder: "Paste the customer requirement.",
    button: "Prepare sales response",
    caps: [
      ["Requirement capture", "Everything needed before quoting."],
      ["Sales follow-up", "A useful next conversation."],
      ["Pricing protection", "The AI will not invent prices."],
    ],
    presets: [
      "Need a quote for three 3.5t vans collecting from Trafford Park and delivering to Leeds next Tuesday.",
      "Customer wants a 12-month plant-hire package for two mini excavators. No site address yet.",
    ],
  },
  {
    id: "tasks",
    n: "10",
    title: "AI Tasks",
    short: "Tasks",
    desc: "Turn requirements into practical work.",
    group: "operations",
    placeholder: "Describe the work that needs doing.",
    button: "Create task plan",
    caps: [
      ["Priorities", "What should happen first."],
      ["Deadlines", "Important dates, if supplied."],
      ["Dependencies", "What must happen before other work."],
    ],
    presets: [
      "Prepare today's operations: two urgent hires, a delayed delivery and a tender deadline on Friday.",
      "Two urgent operational actions conflict for the same driver.",
    ],
  },
  {
    id: "intelligence",
    n: "11",
    title: "Business Intelligence",
    short: "Intelligence",
    desc: "Turn business information into risks, opportunities and next actions.",
    group: "operations",
    placeholder: "Paste business information or describe the situation.",
    button: "Analyse business",
    caps: [
      ["Risks", "Issues that deserve attention."],
      ["Opportunities", "Commercial openings in the information given."],
      ["Priorities", "Practical next actions."],
    ],
    presets: [
      "This week: 14 new enquiries, 3 quotes outstanding over 5 days, one excavator off-hire for repair, tender due Friday.",
      "Utilisation is high on 8-ton machines but mini excavators are sitting idle.",
    ],
  },
  {
    id: "route",
    n: "12",
    title: "Route Intelligence",
    short: "Routes",
    desc: "Build a lawful operating plan for taxis, couriers, multi-drop, removals and freight.",
    group: "operations",
    placeholder:
      "Start, stops, vehicle limits and time windows. One stop per line.",
    button: "Build route plan",
    caps: [
      ["Every transport model", "Passenger, parcel, multi-drop, removals, freight."],
      ["Vehicle-aware", "Height, weight, width, emissions and windows."],
      ["Safety boundary", "No hidden cameras, no evasion, no invented live traffic."],
    ],
    presets: [
      "Plan a multi-stop delivery: depot M17 1AB, then SK1 1AA before 11:00, OL1 1AA before 14:00, return to depot. Long-wheelbase van, 2.4m height limit.",
      "Taxi: collect Manchester Piccadilly 09:15, drop Manchester Airport T2, return via depot.",
    ],
  },
  {
    id: "documents",
    n: "13",
    title: "Document Studio",
    short: "Documents",
    desc: "Draft letters, proposals, contracts, forms and reports from confirmed facts.",
    group: "operations",
    placeholder:
      "Provide the purpose, confirmed facts, dates, prices, clauses and desired outcome. Missing facts will be marked, never invented.",
    button: "Create document",
    caps: [
      ["Business writing", "Letters, proposals, policies and reports."],
      ["Contract drafts", "Placeholders and a legal-review boundary."],
      ["Approval control", "Drafts only until an authorised person signs off."],
    ],
    presets: [
      "Draft a professional proposal from these facts: Northline Plant Hire to supply one 8-ton excavator to Whitaker Groundworks, Manchester, 5 days, collection Monday. Price to be confirmed by sales.",
      "Write a customer letter apologising for a delayed delivery on Thursday, offering a call to reschedule. Do not invent compensation.",
    ],
  },
  {
    id: "auto",
    n: "14",
    title: "Auto Intelligence",
    short: "Auto",
    desc: "Vehicle sourcing, qualification, comparisons and quotation prep.",
    group: "specialist",
    placeholder:
      "Example: Customer needs an EV SUV, 20,000 miles a year, under £650 per month.",
    button: "Run auto intelligence",
    caps: [
      ["Fact-find", "Mileage, budget, term, usage and missing facts."],
      ["Finance support", "PCH, BCH, PCP and salary-sacrifice structure — no invented rates."],
      ["Approval boundary", "Never place an order or guarantee finance."],
    ],
    presets: [
      "Customer needs an EV SUV, 20,000 miles a year, under £650 per month.",
      "Customer wants a premium car but budget and mileage conflict.",
    ],
  },
  {
    id: "freshx",
    n: "15",
    title: "FreshX",
    short: "FreshX",
    desc: "Grower, buyer, market and opportunity intelligence for fresh produce.",
    group: "specialist",
    placeholder:
      "Example: Assess a PiQa Red opportunity for UK premium supermarkets.",
    button: "Assess opportunity",
    caps: [
      ["Market fit", "Buyer, grower and product readiness."],
      ["Evidence", "Mark missing certification and demand — never invent it."],
      ["Next action", "What a human must confirm before a pitch."],
    ],
    presets: [
      "Assess a PiQa Red opportunity for UK premium supermarkets.",
      "Grower information is incomplete but buyer interest appears strong.",
    ],
  },
  {
    id: "tenders",
    n: "16",
    title: "Tender Intelligence",
    short: "Tenders",
    desc: "Requirement analysis, compliance mapping and response preparation.",
    group: "specialist",
    placeholder:
      "Paste tender requirements, deadlines and evidence you actually hold.",
    button: "Prepare response plan",
    caps: [
      ["Compliance map", "Mandatory vs optional requirements."],
      ["Readiness", "What evidence is present, missing or weak."],
      ["Integrity", "Never invent accreditations or past contracts."],
    ],
    presets: [
      "Create a response plan from a tender with mobilisation, insurance and safeguarding requirements. Deadline Friday. We hold public liability and a 12-vehicle fleet. No ISO 45001 yet.",
      "Tender evidence is incomplete and two mandatory requirements are unanswered.",
    ],
  },
  {
    id: "guardian",
    n: "17",
    title: "Guardian",
    short: "Guardian",
    desc: "Audit trail, approval boundaries and workspace security posture.",
    group: "specialist",
    placeholder: "",
    button: "",
    caps: [
      ["Tenant isolation", "Your records stay in your workspace."],
      ["Approval gates", "Consequential actions stay prepared-only."],
      ["Audit", "Important activity is recorded."],
    ],
    presets: [],
  },
];

export const MODULE_MAP = Object.fromEntries(
  MODULES.map((m) => [m.id, m]),
) as Record<ModuleId, ModuleDef>;

export const GROUPS: { id: NavGroup; label: string }[] = [
  { id: "workspace", label: "Workspace" },
  { id: "operations", label: "Operations" },
  { id: "specialist", label: "Specialist" },
];

export function isModuleId(value: string): value is ModuleId {
  return value in MODULE_MAP;
}
