import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function scoreEnquiry(text: string) {
  let s = 30;
  const x = text.toLowerCase();
  for (const k of [
    "urgent",
    "today",
    "tomorrow",
    "quote",
    "price",
    "book",
    "appointment",
    "need",
    "buy",
    "lease",
    "demo",
    "purchase",
    "reserve",
    "same-day",
    "asap",
  ]) {
    if (x.includes(k)) s += 5;
  }
  return Math.min(99, s);
}

export function formatWhen(iso: string) {
  try {
    return new Date(iso).toLocaleString("en-GB", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return iso;
  }
}
