import type { ModuleId } from "./modules";

export type AgentId = ModuleId | "secretary";

export type Agent = {
  id: AgentId;
  name: string;
  role: string;
  voice: string;
  colour: string;
  listensTo: AgentId[];
};

export const AGENTS: Agent[] = [
  {
    id: "secretary",
    name: "Cora",
    role: "AI Secretary",
    voice: "eve",
    colour: "#c9a24a",
    listensTo: [
      "leads",
      "quotes",
      "calendar",
      "bookings",
      "tasks",
      "support",
    ],
  },
  {
    id: "receptionist",
    name: "Cora",
    role: "Reception",
    voice: "eve",
    colour: "#c9a24a",
    listensTo: ["leads", "quotes", "calendar", "bookings", "tasks"],
  },
  {
    id: "calendar",
    name: "Callum",
    role: "Calendar",
    voice: "orion",
    colour: "#3d9b8f",
    listensTo: ["secretary", "bookings", "tasks"],
  },
  {
    id: "bookings",
    name: "Blair",
    role: "Bookings",
    voice: "ara",
    colour: "#d4785a",
    listensTo: ["secretary", "calendar", "quotes"],
  },
  {
    id: "leads",
    name: "Lena",
    role: "Leads",
    voice: "iris",
    colour: "#c9a24a",
    listensTo: ["secretary", "quotes", "tasks"],
  },
  {
    id: "social",
    name: "Soren",
    role: "Social",
    voice: "leo",
    colour: "#3d9b8f",
    listensTo: ["marketing", "intelligence"],
  },
  {
    id: "marketing",
    name: "Mara",
    role: "Marketing",
    voice: "luna",
    colour: "#d4785a",
    listensTo: ["social", "leads", "intelligence"],
  },
  {
    id: "support",
    name: "Sage",
    role: "Support",
    voice: "liora",
    colour: "#3d9b8f",
    listensTo: ["secretary", "tasks", "quotes"],
  },
  {
    id: "quotes",
    name: "Quinn",
    role: "Quotes",
    voice: "atlas",
    colour: "#c9a24a",
    listensTo: ["secretary", "leads", "documents"],
  },
  {
    id: "tasks",
    name: "Tessa",
    role: "Tasks",
    voice: "celeste",
    colour: "#d4785a",
    listensTo: ["secretary", "support", "calendar"],
  },
  {
    id: "intelligence",
    name: "Indira",
    role: "Intelligence",
    voice: "ursa",
    colour: "#3d9b8f",
    listensTo: ["leads", "quotes", "tenders"],
  },
  {
    id: "route",
    name: "Rowan",
    role: "Routes",
    voice: "kepler",
    colour: "#c9a24a",
    listensTo: ["bookings", "tasks"],
  },
  {
    id: "documents",
    name: "Dorian",
    role: "Documents",
    voice: "helix",
    colour: "#d4785a",
    listensTo: ["quotes", "tenders", "support"],
  },
  {
    id: "auto",
    name: "Axel",
    role: "Auto",
    voice: "rex",
    colour: "#3d9b8f",
    listensTo: ["leads", "quotes", "documents"],
  },
  {
    id: "freshx",
    name: "Flora",
    role: "FreshX",
    voice: "aurora",
    colour: "#d4785a",
    listensTo: ["leads", "intelligence"],
  },
  {
    id: "tenders",
    name: "Thea",
    role: "Tenders",
    voice: "carina",
    colour: "#c9a24a",
    listensTo: ["documents", "intelligence", "quotes"],
  },
  {
    id: "guardian",
    name: "Guardian",
    role: "Oversight",
    voice: "eve",
    colour: "#8b5c00",
    listensTo: [],
  },
];

export const AGENT_MAP = Object.fromEntries(AGENTS.map((a) => [a.id, a])) as Record<
  AgentId,
  Agent
>;

export function agentFor(id: string): Agent {
  return AGENT_MAP[id as AgentId] ?? AGENT_MAP.secretary;
}
