import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { contextFor, SYSTEM_PROMPT } from "@/lib/prompts";
import { agentFor } from "@/lib/agents";
import { scoreEnquiry } from "@/lib/utils";

const Input = z.object({
  tool: z.string().min(1).max(40),
  message: z.string().min(1).max(4000),
});

export type AiResult =
  | { ok: true; reply: string; tool: string; applied: string[] }
  | { ok: false; error: string };

const VALID_HANDOFF = new Set([
  "secretary",
  "calendar",
  "bookings",
  "leads",
  "social",
  "marketing",
  "support",
  "quotes",
  "tasks",
  "intelligence",
  "route",
  "documents",
  "auto",
  "freshx",
  "tenders",
  "guardian",
]);

const DeskAction = z.object({
  type: z.enum(["contact", "task", "booking", "approval", "deal", "document", "campaign"]),
  name: z.string().optional(),
  need: z.string().optional(),
  title: z.string().optional(),
  contactName: z.string().optional(),
  bookingType: z.string().optional(),
  date: z.string().optional(),
  time: z.string().optional(),
  notes: z.string().optional(),
  action: z.string().optional(),
  summary: z.string().optional(),
  body: z.string().optional(),
  channel: z.string().optional(),
  docType: z.string().optional(),
});

const DeskOut = z.object({
  speak: z.string().optional(),
  brief: z.string().optional(),
  reply: z.string().optional(),
  handoffs: z
    .array(
      z.object({
        to: z.string(),
        subject: z.string(),
        body: z.string().optional(),
      }),
    )
    .optional(),
  actions: z.array(DeskAction).optional(),
});

async function grok(system: string, user: string, maxTokens = 800, json = false) {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false as const, error: "AI is not available in this environment." };
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: json ? 0.2 : 0.3,
      max_tokens: maxTokens,
      ...(json ? { response_format: { type: "json_object" } } : {}),
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });
  if (!res.ok) return { ok: false as const, error: `AI service error (${res.status}). Try again.` };
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const reply = body.choices?.[0]?.message?.content?.trim();
  if (!reply) return { ok: false as const, error: "The AI service returned an empty response." };
  return { ok: true as const, reply };
}

function parseDesk(rawText: string) {
  try {
    const raw = rawText.replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
    const start = raw.indexOf("{");
    const end = raw.lastIndexOf("}");
    return DeskOut.parse(JSON.parse(raw.slice(start, end + 1)));
  } catch {
    return null;
  }
}

async function teamContext(userId: string) {
  const sql = await getSql();
  const handoffs = await sql<{ from_agent: string; to_agent: string; subject: string; status: string }>`
    select from_agent, to_agent, subject, status from handoffs where user_id = ${userId} order by created_at desc limit 8
  `;
  const contacts = await sql<{ name: string; need: string | null; status: string }>`
    select name, need, status from contacts where user_id = ${userId} order by created_at desc limit 6
  `;
  const tasks = await sql<{ title: string; status: string }>`
    select title, status from tasks where user_id = ${userId} and status = 'open' order by created_at desc limit 6
  `;
  const approvals = await sql<{ summary: string; status: string }>`
    select summary, status from approvals where user_id = ${userId} and status = 'pending' order by created_at desc limit 6
  `;
  return [
    "Open handoffs:",
    ...handoffs.map((h) => `- ${h.from_agent} → ${h.to_agent}: ${h.subject} (${h.status})`),
    "Recent contacts:",
    ...contacts.map((c) => `- ${c.name}: ${c.need ?? "no need recorded"} [${c.status}]`),
    "Open tasks:",
    ...tasks.map((t) => `- ${t.title}`),
    "Pending approvals:",
    ...approvals.map((a) => `- ${a.summary} [${a.status}]`),
  ].join("\n");
}

async function applyDeskActions(
  userId: string,
  fromAgent: string,
  parsed: z.infer<typeof DeskOut>,
) {
  const sql = await getSql();
  const applied: string[] = [];
  for (const h of parsed.handoffs ?? []) {
    const to = h.to.slice(0, 40).toLowerCase();
    if (!VALID_HANDOFF.has(to) || to === fromAgent) continue;
    await sql`insert into handoffs (id, user_id, from_agent, to_agent, subject, body, status)
      values (${crypto.randomUUID()}, ${userId}, ${fromAgent}, ${to}, ${h.subject.slice(0, 180)}, ${h.body ?? null}, ${"open"})`;
    applied.push(`Briefed ${to}: ${h.subject}`);
  }
  for (const a of parsed.actions ?? []) {
    if (a.type === "contact" && a.name) {
      const score = scoreEnquiry(a.need ?? a.notes ?? "");
      await sql`insert into contacts (id, user_id, name, need, source, score, status)
        values (${crypto.randomUUID()}, ${userId}, ${a.name}, ${a.need ?? a.notes ?? null}, ${fromAgent}, ${score}, ${"new"})`;
      applied.push(`Lead captured: ${a.name}`);
    }
    if (a.type === "task" && a.title) {
      await sql`insert into tasks (id, user_id, title, owner, due_date, status, priority, notes)
        values (${crypto.randomUUID()}, ${userId}, ${a.title}, ${fromAgent}, ${a.date ?? new Date().toISOString().slice(0, 10)}, ${"open"}, ${"normal"}, ${a.notes ?? null})`;
      applied.push(`Task prepared: ${a.title}`);
    }
    if (a.type === "booking" && a.contactName && a.date && a.time) {
      const bookingId = crypto.randomUUID();
      await sql`insert into bookings (id, user_id, contact_name, type, date, time, notes, status)
        values (${bookingId}, ${userId}, ${a.contactName}, ${a.bookingType ?? "Appointment"}, ${a.date}, ${a.time}, ${a.notes ?? "Prepared — not confirmed"}, ${"pending"})`;
      const payload = JSON.stringify({
        bookingId,
        contactName: a.contactName,
        date: a.date,
        time: a.time,
      });
      await sql`insert into approvals (id, user_id, agent, action, summary, payload, status)
        values (${crypto.randomUUID()}, ${userId}, ${fromAgent}, ${"confirm_booking"}, ${"Confirm booking for " + a.contactName}, ${payload}, ${"pending"})`;
      applied.push(`Booking prepared for ${a.contactName} — approval required`);
    }
    if (a.type === "deal" && a.title) {
      await sql`insert into deals (id, user_id, title, stage, notes)
        values (${crypto.randomUUID()}, ${userId}, ${a.title}, ${"lead"}, ${a.notes ?? null})`;
      applied.push(`Pipeline record: ${a.title}`);
    }
    if (a.type === "document" && a.title && (a.body || a.notes)) {
      const documentId = crypto.randomUUID();
      await sql`insert into documents (id, user_id, type, title, body, status)
        values (${documentId}, ${userId}, ${a.docType ?? "Draft"}, ${a.title}, ${a.body ?? a.notes ?? ""}, ${"draft"})`;
      const payload = JSON.stringify({ documentId, title: a.title });
      await sql`insert into approvals (id, user_id, agent, action, summary, payload, status)
        values (${crypto.randomUUID()}, ${userId}, ${fromAgent}, ${"ready_document"}, ${"Release document: " + a.title}, ${payload}, ${"pending"})`;
      applied.push(`Document drafted: ${a.title} — approval required`);
    }
    if (a.type === "campaign" && a.title && (a.body || a.notes)) {
      const campaignId = crypto.randomUUID();
      await sql`insert into campaigns (id, user_id, title, channel, body, goal, content, status)
        values (${campaignId}, ${userId}, ${a.title}, ${a.channel ?? "internal"}, ${a.body ?? a.notes ?? ""}, ${a.title}, ${a.body ?? a.notes ?? ""}, ${"draft"})`;
      const payload = JSON.stringify({ campaignId, title: a.title });
      await sql`insert into approvals (id, user_id, agent, action, summary, payload, status)
        values (${crypto.randomUUID()}, ${userId}, ${fromAgent}, ${"publish_campaign"}, ${"Publish campaign: " + a.title}, ${payload}, ${"pending"})`;
      applied.push(`Campaign drafted: ${a.title} — not published`);
    }
    if (a.type === "approval" && a.summary) {
      await sql`insert into approvals (id, user_id, agent, action, summary, payload, status)
        values (${crypto.randomUUID()}, ${userId}, ${fromAgent}, ${a.action ?? "review"}, ${a.summary}, ${a.notes ?? null}, ${"pending"})`;
      applied.push(`Approval requested: ${a.summary}`);
    }
  }
  return applied;
}

export const runIntelligence = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => Input.parse(input))
  .handler(async ({ context, data }): Promise<AiResult> => {
    const agent = agentFor(data.tool);
    const desk = await teamContext(context.userId);
    const result = await grok(
      `${SYSTEM_PROMPT}\n\nYou are ${agent.name}, ${agent.role} specialist in Caelomere.
You can see the team desk. You SAVE work as records. You never invent prices, send messages, or confirm bookings as done.

Return ONLY JSON:
{
  "reply": "written work for the human",
  "handoffs": [{"to":"tasks","subject":"...","body":"..."}],
  "actions": [{"type":"contact|task|booking|approval|deal|document|campaign","name":"","need":"","title":"","contactName":"","bookingType":"","date":"YYYY-MM-DD","time":"HH:MM","notes":"","action":"","summary":"","body":"","channel":"","docType":""}]
}
Valid handoff to: ${[...VALID_HANDOFF].join(", ")}
Bookings stay pending. Campaigns and outbound messages stay as approval requests.

${contextFor(data.tool)}

TEAM DESK
${desk}`,
      data.message,
      900,
      true,
    );
    if (!result.ok) return result;

    const parsed = parseDesk(result.reply) ?? {
      reply: result.reply,
      handoffs: [],
      actions: [],
    };
    const reply = parsed.reply || parsed.brief || result.reply;

    const sql = await getSql();
    await sql`insert into ai_runs (id, user_id, tool, prompt, reply)
      values (${crypto.randomUUID()}, ${context.userId}, ${data.tool}, ${data.message}, ${reply})`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"ai." + data.tool}, ${data.message.slice(0, 180)})`;
    await sql`insert into handoffs (id, user_id, from_agent, to_agent, subject, body, status)
      values (${crypto.randomUUID()}, ${context.userId}, ${data.tool}, ${"secretary"}, ${agent.name + " prepared work"}, ${reply.slice(0, 500)}, ${"note"})`;

    const applied = await applyDeskActions(context.userId, data.tool, parsed);

    for (const line of reply.split("\n")) {
      const m = line.match(/^Handoff:\s*([A-Za-z]+)\s*[—–:\-]\s*(.+)$/i);
      if (!m) continue;
      const to = m[1].toLowerCase();
      if (!VALID_HANDOFF.has(to) || to === data.tool) continue;
      await sql`insert into handoffs (id, user_id, from_agent, to_agent, subject, body, status)
        values (${crypto.randomUUID()}, ${context.userId}, ${data.tool}, ${to}, ${m[2].slice(0, 180)}, ${reply.slice(0, 500)}, ${"open"})`;
    }

    return { ok: true, reply, tool: data.tool, applied };
  });

export const talkToCora = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ message: z.string().min(1).max(4000) }).parse(input))
  .handler(async ({ context, data }) => {
    const desk = await teamContext(context.userId);
    const result = await grok(
      `${SYSTEM_PROMPT}

You are Cora, Caelomere's AI secretary. Composed British English. Short sentences when speaking.
You coordinate specialists. You never invent prices, send messages, or confirm bookings as done.
You PREPARE work and request approval for anything that would leave the company.

Return ONLY JSON:
{
  "speak": "one or two spoken sentences",
  "brief": "written briefing",
  "handoffs": [{"to":"leads","subject":"...","body":"..."}],
  "actions": [{"type":"contact|task|booking|approval|deal|document|campaign","name":"","need":"","title":"","contactName":"","bookingType":"","date":"YYYY-MM-DD","time":"HH:MM","notes":"","action":"","summary":"","body":"","channel":"","docType":""}]
}
Valid handoff to: ${[...VALID_HANDOFF].filter((x) => x !== "secretary").join(", ")}
Booking actions stay pending. Communications stay as approval requests. Never claim a message was sent.

TEAM DESK
${desk}`,
      data.message,
      700,
      true,
    );
    if (!result.ok) return result;

    const parsed = parseDesk(result.reply) ?? {
      speak: result.reply.slice(0, 280),
      brief: result.reply,
      handoffs: [],
      actions: [],
    };
    const brief = parsed.brief || parsed.reply || result.reply;
    const speak = parsed.speak || brief.slice(0, 280);

    const sql = await getSql();
    await sql`insert into agent_messages (id, user_id, agent, role, body)
      values (${crypto.randomUUID()}, ${context.userId}, ${"secretary"}, ${"user"}, ${data.message})`;
    await sql`insert into agent_messages (id, user_id, agent, role, body)
      values (${crypto.randomUUID()}, ${context.userId}, ${"secretary"}, ${"agent"}, ${brief})`;
    await sql`insert into ai_runs (id, user_id, tool, prompt, reply)
      values (${crypto.randomUUID()}, ${context.userId}, ${"secretary"}, ${data.message}, ${brief})`;

    const applied = await applyDeskActions(context.userId, "secretary", parsed);

    return {
      ok: true as const,
      speak,
      brief,
      applied,
    };
  });

export const speakText = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ text: z.string().min(1).max(600), voice: z.string().max(40).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Voice is not available." };
    const res = await fetch("https://api.x.ai/v1/tts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        text: data.text.slice(0, 500),
        voice_id: data.voice ?? "eve",
      }),
    });
    if (!res.ok) return { ok: false as const, error: `Voice error (${res.status}).` };
    const buf = Buffer.from(await res.arrayBuffer());
    return {
      ok: true as const,
      audio: buf.toString("base64"),
      mime: res.headers.get("content-type") || "audio/mpeg",
    };
  });
