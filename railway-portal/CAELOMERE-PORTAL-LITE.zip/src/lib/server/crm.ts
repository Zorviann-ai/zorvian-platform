import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { ensureWorkspace } from "./workspace";

export type Company = {
  id: string;
  name: string;
  industry: string | null;
  website: string | null;
  phone: string | null;
  email: string | null;
  notes: string | null;
  createdAt: string;
};

export type Deal = {
  id: string;
  title: string;
  companyId: string | null;
  contactId: string | null;
  stage: string;
  valueNote: string | null;
  notes: string | null;
  createdAt: string;
};

export type Handoff = {
  id: string;
  fromAgent: string;
  toAgent: string;
  subject: string;
  body: string | null;
  status: string;
  createdAt: string;
};

export type Approval = {
  id: string;
  agent: string;
  action: string;
  summary: string;
  payload: string | null;
  status: string;
  result: string | null;
  createdAt: string;
};

export type Invoice = {
  id: string;
  contactName: string;
  reference: string | null;
  amountNote: string | null;
  dueDate: string | null;
  status: string;
  notes: string | null;
  createdAt: string;
};

export type Campaign = {
  id: string;
  title: string;
  channel: string;
  body: string;
  status: string;
  createdAt: string;
};

export type Note = {
  id: string;
  parentType: string;
  parentId: string;
  body: string;
  createdAt: string;
};

export const PIPELINE = ["lead", "qualified", "quoted", "won", "lost"] as const;

function rowCompany(r: Record<string, unknown>): Company {
  return {
    id: String(r.id),
    name: String(r.name),
    industry: (r.industry as string) ?? null,
    website: (r.website as string) ?? null,
    phone: (r.phone as string) ?? null,
    email: (r.email as string) ?? null,
    notes: (r.notes as string) ?? null,
    createdAt: String(r.created_at),
  };
}

export const getCrm = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureWorkspace(context.userId);
    const sql = await getSql();
    const companies = await sql`select * from companies where user_id = ${context.userId} order by name asc`;
    const deals = await sql`select * from deals where user_id = ${context.userId} order by created_at desc`;
    const handoffs = await sql`select * from handoffs where user_id = ${context.userId} order by created_at desc limit 40`;
    const approvals = await sql`select * from approvals where user_id = ${context.userId} order by created_at desc limit 40`;
    const invoices = await sql`select * from invoices where user_id = ${context.userId} order by created_at desc limit 40`;
    const campaigns = await sql`select * from campaigns where user_id = ${context.userId} order by created_at desc limit 20`;
    const notes = await sql`select * from notes where user_id = ${context.userId} order by created_at desc limit 80`;
    return {
      companies: companies.map(rowCompany),
      deals: deals.map((r) => ({
        id: String(r.id),
        title: String(r.title),
        companyId: (r.company_id as string) ?? null,
        contactId: (r.contact_id as string) ?? null,
        stage: String(r.stage),
        valueNote: (r.value_note as string) ?? null,
        notes: (r.notes as string) ?? null,
        createdAt: String(r.created_at),
      })),
      handoffs: handoffs.map((r) => ({
        id: String(r.id),
        fromAgent: String(r.from_agent),
        toAgent: String(r.to_agent),
        subject: String(r.subject),
        body: (r.body as string) ?? null,
        status: String(r.status),
        createdAt: String(r.created_at),
      })),
      approvals: approvals.map((r) => ({
        id: String(r.id),
        agent: String(r.agent),
        action: String(r.action),
        summary: String(r.summary),
        payload: (r.payload as string) ?? null,
        status: String(r.status),
        result: (r.result as string) ?? null,
        createdAt: String(r.created_at),
      })),
      invoices: invoices.map((r) => ({
        id: String(r.id),
        contactName: String(r.contact_name),
        reference: (r.reference as string) ?? null,
        amountNote: (r.amount_note as string) ?? null,
        dueDate: (r.due_date as string) ?? null,
        status: String(r.status),
        notes: (r.notes as string) ?? null,
        createdAt: String(r.created_at),
      })),
      campaigns: campaigns.map((r) => ({
        id: String(r.id),
        title: String(r.title),
        channel: String(r.channel),
        body: String(r.body),
        status: String(r.status),
        createdAt: String(r.created_at),
      })),
      notes: notes.map((r) => ({
        id: String(r.id),
        parentType: String(r.parent_type),
        parentId: String(r.parent_id),
        body: String(r.body),
        createdAt: String(r.created_at),
      })),
    };
  });

export const saveCompany = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        id: z.string().optional(),
        name: z.string().min(1).max(160),
        industry: z.string().max(80).optional(),
        website: z.string().max(180).optional(),
        phone: z.string().max(40).optional(),
        email: z.string().max(180).optional(),
        notes: z.string().max(4000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = data.id || crypto.randomUUID();
    if (data.id) {
      await sql`update companies set name = ${data.name}, industry = ${data.industry ?? null}, website = ${data.website ?? null}, phone = ${data.phone ?? null}, email = ${data.email ?? null}, notes = ${data.notes ?? null}
        where id = ${id} and user_id = ${context.userId}`;
    } else {
      await sql`insert into companies (id, user_id, name, industry, website, phone, email, notes)
        values (${id}, ${context.userId}, ${data.name}, ${data.industry ?? null}, ${data.website ?? null}, ${data.phone ?? null}, ${data.email ?? null}, ${data.notes ?? null})`;
    }
    return { id };
  });

export const deleteCompany = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`delete from companies where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const updateContact = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        id: z.string(),
        name: z.string().min(1).max(120),
        company: z.string().max(120).optional(),
        email: z.string().max(180).optional(),
        phone: z.string().max(40).optional(),
        need: z.string().max(2000).optional(),
        status: z.string().max(40).optional(),
        tags: z.string().max(200).optional(),
        notes: z.string().max(4000).optional(),
        companyId: z.string().optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update contacts set name = ${data.name}, company = ${data.company ?? null}, email = ${data.email ?? null}, phone = ${data.phone ?? null}, need = ${data.need ?? null}, status = ${data.status ?? "new"}, tags = ${data.tags ?? null}, notes = ${data.notes ?? null}, company_id = ${data.companyId ?? null}
      where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const deleteContact = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`delete from contacts where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const saveDeal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        id: z.string().optional(),
        title: z.string().min(1).max(180),
        companyId: z.string().optional(),
        contactId: z.string().optional(),
        stage: z.enum(PIPELINE).optional(),
        valueNote: z.string().max(120).optional(),
        notes: z.string().max(4000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = data.id || crypto.randomUUID();
    const stage = data.stage ?? "lead";
    if (data.id) {
      await sql`update deals set title = ${data.title}, company_id = ${data.companyId ?? null}, contact_id = ${data.contactId ?? null}, stage = ${stage}, value_note = ${data.valueNote ?? null}, notes = ${data.notes ?? null}
        where id = ${id} and user_id = ${context.userId}`;
    } else {
      await sql`insert into deals (id, user_id, title, company_id, contact_id, stage, value_note, notes)
        values (${id}, ${context.userId}, ${data.title}, ${data.companyId ?? null}, ${data.contactId ?? null}, ${stage}, ${data.valueNote ?? null}, ${data.notes ?? null})`;
    }
    return { id };
  });

export const moveDeal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ id: z.string(), stage: z.enum(PIPELINE) }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update deals set stage = ${data.stage} where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const deleteDeal = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => z.object({ id: z.string() }).parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`delete from deals where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const addNote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        parentType: z.string().min(1).max(40),
        parentId: z.string().min(1).max(80),
        body: z.string().min(1).max(4000),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into notes (id, user_id, parent_type, parent_id, body)
      values (${id}, ${context.userId}, ${data.parentType}, ${data.parentId}, ${data.body})`;
    return { id };
  });

export const createHandoff = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        fromAgent: z.string().min(1).max(40),
        toAgent: z.string().min(1).max(40),
        subject: z.string().min(1).max(180),
        body: z.string().max(8000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into handoffs (id, user_id, from_agent, to_agent, subject, body, status)
      values (${id}, ${context.userId}, ${data.fromAgent}, ${data.toAgent}, ${data.subject}, ${data.body ?? null}, ${"open"})`;
    return { id };
  });

export const setHandoffStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({ id: z.string(), status: z.enum(["open", "done", "note"]) })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update handoffs set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const requestApproval = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        agent: z.string().min(1).max(40),
        action: z.string().min(1).max(80),
        summary: z.string().min(1).max(500),
        payload: z.string().max(8000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into approvals (id, user_id, agent, action, summary, payload, status)
      values (${id}, ${context.userId}, ${data.agent}, ${data.action}, ${data.summary}, ${data.payload ?? null}, ${"pending"})`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"approval.requested"}, ${data.summary})`;
    return { id };
  });

export const decideApproval = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({ id: z.string(), status: z.enum(["approved", "rejected"]) })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql`
      select * from approvals where id = ${data.id} and user_id = ${context.userId} limit 1
    `;
    const row = rows[0];
    if (!row) return { ok: false as const, error: "Approval not found." };
    if (String(row.status) !== "pending") {
      return { ok: false as const, error: "This item has already been decided." };
    }

    let payload: Record<string, string> = {};
    const raw = String(row.payload ?? "");
    try {
      const parsed = JSON.parse(raw) as Record<string, unknown>;
      for (const [k, v] of Object.entries(parsed)) payload[k] = String(v ?? "");
    } catch {
      payload = { raw, campaignId: raw, documentId: raw, bookingId: raw };
    }

    const action = String(row.action);
    let result = "Decision recorded.";

    if (data.status === "approved") {
      if (action === "confirm_booking" && payload.bookingId) {
        await sql`update bookings set status = ${"confirmed"} where id = ${payload.bookingId} and user_id = ${context.userId}`;
        result = "Booking confirmed on the desk. No calendar provider is connected.";
      } else if (action === "publish_campaign") {
        const cid = payload.campaignId || payload.raw;
        if (cid) {
          await sql`update campaigns set status = ${"approved"} where id = ${cid} and user_id = ${context.userId}`;
        }
        result = "Campaign marked approved. Social publishing is NOT CONNECTED — nothing was posted.";
      } else if (action === "ready_document") {
        if (payload.documentId) {
          await sql`update documents set status = ${"ready"} where id = ${payload.documentId} and user_id = ${context.userId}`;
        }
        result = "Document marked ready. It has not been sent.";
      } else if (action.startsWith("send_")) {
        if (payload.documentId) {
          await sql`update documents set status = ${"ready"} where id = ${payload.documentId} and user_id = ${context.userId}`;
        }
        result = "Approved on the desk. Email, SMS and WhatsApp are parked — nothing was sent.";
      }
    } else if (action === "confirm_booking" && payload.bookingId) {
      await sql`update bookings set status = ${"cancelled"} where id = ${payload.bookingId} and user_id = ${context.userId}`;
      result = "Booking cancelled.";
    } else if (action === "publish_campaign") {
      const cid = payload.campaignId || payload.raw;
      if (cid) {
        await sql`update campaigns set status = ${"held"} where id = ${cid} and user_id = ${context.userId}`;
      }
      result = "Campaign held. Not published.";
    } else {
      result = "Rejected. No further action taken.";
    }

    try {
      await sql`update approvals set status = ${data.status}, result = ${result} where id = ${data.id} and user_id = ${context.userId}`;
    } catch {
      await sql`update approvals set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
    }
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"approval." + data.status}, ${result})`;
    return { ok: true as const, result };
  });

export const saveInvoice = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        contactName: z.string().min(1).max(120),
        reference: z.string().max(80).optional(),
        amountNote: z.string().max(80).optional(),
        dueDate: z.string().max(20).optional(),
        notes: z.string().max(2000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into invoices (id, user_id, contact_name, reference, amount_note, due_date, status, notes)
      values (${id}, ${context.userId}, ${data.contactName}, ${data.reference ?? null}, ${data.amountNote ?? null}, ${data.dueDate ?? null}, ${"draft"}, ${data.notes ?? null})`;
    return { id };
  });

export const saveCampaign = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        title: z.string().min(1).max(160),
        channel: z.string().min(1).max(40),
        body: z.string().min(1).max(8000),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into campaigns (id, user_id, title, channel, body, goal, content, status)
      values (${id}, ${context.userId}, ${data.title}, ${data.channel}, ${data.body}, ${data.title}, ${data.body}, ${"draft"})`;
    await sql`insert into approvals (id, user_id, agent, action, summary, payload, status)
      values (${crypto.randomUUID()}, ${context.userId}, ${"marketing"}, ${"publish_campaign"}, ${"Publish campaign: " + data.title}, ${JSON.stringify({ campaignId: id, title: data.title })}, ${"pending"})`;
    return { id };
  });

export const submitPublicEnquiry = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(1).max(120),
        email: z.string().email().max(180),
        company: z.string().max(120).optional(),
        message: z.string().min(1).max(4000),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const sql = await getSql();
    await sql`insert into public_enquiries (id, name, email, company, message)
      values (${crypto.randomUUID()}, ${data.name}, ${data.email}, ${data.company ?? null}, ${data.message})`;
    return { ok: true as const };
  });
