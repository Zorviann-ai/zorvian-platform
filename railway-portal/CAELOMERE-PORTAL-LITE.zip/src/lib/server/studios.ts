import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { ALICE_TELLERS, GLASS_TELLERS } from "@/data/tellers";

const TELLERS = [...ALICE_TELLERS, ...GLASS_TELLERS];

async function grok(system: string, user: string, maxTokens = 700) {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false as const, error: "The studio voice is not available just now." };
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "grok-4.5",
      temperature: 0.55,
      max_tokens: maxTokens,
      messages: [
        { role: "system", content: system },
        { role: "user", content: user },
      ],
    }),
  });
  if (!res.ok) return { ok: false as const, error: `Studio error (${res.status}).` };
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const reply = body.choices?.[0]?.message?.content?.trim();
  if (!reply) return { ok: false as const, error: "The teller had nothing to say." };
  return { ok: true as const, reply };
}

export const tellTheStory = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z
      .object({
        tellerId: z.string().min(1).max(40),
        bookTitle: z.string().min(1).max(180),
        chapterTitle: z.string().min(1).max(180),
        passage: z.string().min(1).max(6000),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const teller = TELLERS.find((t) => t.id === data.tellerId) ?? ALICE_TELLERS[0];
    const result = await grok(
      `You are ${teller.name} in Lewis Carroll's public-domain book "${data.bookTitle}".
You are the storyteller now. First person only. British Victorian English.
Manner: ${teller.manner}
Rules:
- Retell this chapter as YOU lived it or watched it. Stay faithful to Carroll's events.
- Do not invent plot. Do not use any film-studio names or later designs.
- Do not claim this is Carroll's original wording. It is your telling of his events.
- 180–280 words. Short sentences when you speak.
- End on a line that invites the next page.`,
      `Chapter: ${data.chapterTitle}\n\nCarroll's text (source, not to copy wholesale):\n${data.passage}`,
      700,
    );
    if (!result.ok) return result;
    return {
      ok: true as const,
      tellerId: teller.id,
      tellerName: teller.name,
      voice: teller.voice,
      telling: result.reply,
    };
  });

export const speakTelling = createServerFn({ method: "POST" })
  .validator((input: unknown) =>
    z.object({ text: z.string().min(1).max(900), voice: z.string().max(40).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Voice is not available." };
    const res = await fetch("https://api.x.ai/v1/tts", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        text: data.text.slice(0, 500),
        voice_id: data.voice ?? "eve",
      }),
    });
    if (!res.ok) return { ok: false as const, error: `Voice error (${res.status}).` };
    const buf = Buffer.from(await res.arrayBuffer());
    return {
      ok: true as const,
      audio: buf.toString("base64"),
      mime: res.headers.get("content-type") || "audio/mpeg",
    };
  });
