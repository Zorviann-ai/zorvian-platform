import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { scoreEnquiry } from "@/lib/utils";

export type Workspace = {
  companyName: string;
  industry: string;
  seeded: boolean;
};

export type Contact = {
  id: string;
  name: string;
  company: string | null;
  email: string | null;
  phone: string | null;
  need: string | null;
  source: string;
  score: number;
  status: string;
  createdAt: string;
};

export type Task = {
  id: string;
  title: string;
  owner: string | null;
  dueDate: string | null;
  status: string;
  priority: string;
  notes: string | null;
  createdAt: string;
};

export type Booking = {
  id: string;
  contactName: string;
  type: string;
  date: string;
  time: string;
  notes: string | null;
  status: string;
  createdAt: string;
};

export type DocumentRow = {
  id: string;
  type: string;
  title: string;
  body: string;
  status: string;
  createdAt: string;
};

export type Opportunity = {
  id: string;
  kind: string;
  title: string;
  detail: string | null;
  stage: string;
  notes: string | null;
  createdAt: string;
};

export type Tender = {
  id: string;
  title: string;
  ref: string | null;
  deadline: string | null;
  valueNote: string | null;
  requirements: string | null;
  analysis: string | null;
  status: string;
  createdAt: string;
};

export type RouteRow = {
  id: string;
  operation: string;
  vehicle: string | null;
  startPoint: string | null;
  stops: string | null;
  plan: string | null;
  status: string;
  createdAt: string;
};

export type AuditEvent = {
  id: string;
  event: string;
  detail: string | null;
  createdAt: string;
};

export type Dashboard = {
  workspace: Workspace;
  contacts: Contact[];
  tasks: Task[];
  bookings: Booking[];
  documents: DocumentRow[];
  opportunities: Opportunity[];
  tenders: Tender[];
  routes: RouteRow[];
  audit: AuditEvent[];
  counts: {
    contacts: number;
    openTasks: number;
    pendingBookings: number;
    documents: number;
    aiRuns: number;
  };
};

export async function ensureWorkspace(userId: string, displayName?: string) {
  const sql = await getSql();
  const existing = await sql<{ user_id: string }>`
    select user_id from workspaces where user_id = ${userId}
  `;
  if (existing.length) return;
  const company = displayName?.trim() || "My business";
  await sql`insert into workspaces (user_id, company_name)
    values (${userId}, ${company})`;
  await sql`insert into audit_events (id, user_id, event, detail)
    values (${crypto.randomUUID()}, ${userId}, ${"workspace.created"}, ${company})`;
}

function mapContact(r: Record<string, unknown>): Contact {
  return {
    id: String(r.id),
    name: String(r.name),
    company: (r.company as string) ?? null,
    email: (r.email as string) ?? null,
    phone: (r.phone as string) ?? null,
    need: (r.need as string) ?? null,
    source: String(r.source),
    score: Number(r.score),
    status: String(r.status),
    createdAt: String(r.created_at),
  };
}

function mapTask(r: Record<string, unknown>): Task {
  return {
    id: String(r.id),
    title: String(r.title),
    owner: (r.owner as string) ?? null,
    dueDate: (r.due_date as string) ?? null,
    status: String(r.status),
    priority: String(r.priority),
    notes: (r.notes as string) ?? null,
    createdAt: String(r.created_at),
  };
}

function mapBooking(r: Record<string, unknown>): Booking {
  return {
    id: String(r.id),
    contactName: String(r.contact_name),
    type: String(r.type),
    date: String(r.date),
    time: String(r.time),
    notes: (r.notes as string) ?? null,
    status: String(r.status),
    createdAt: String(r.created_at),
  };
}

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Dashboard> => {
    await ensureWorkspace(context.userId);
    const sql = await getSql();
    const ws = await sql<{
      company_name: string;
      industry: string;
      seeded: boolean;
    }>`select company_name, industry, seeded from workspaces where user_id = ${context.userId}`;
    const contacts = await sql`select * from contacts where user_id = ${context.userId} order by created_at desc limit 40`;
    const tasks = await sql`select * from tasks where user_id = ${context.userId} order by created_at desc limit 40`;
    const bookings = await sql`select * from bookings where user_id = ${context.userId} order by date asc, time asc limit 40`;
    const documents = await sql`select * from documents where user_id = ${context.userId} order by created_at desc limit 20`;
    const opportunities = await sql`select * from opportunities where user_id = ${context.userId} order by created_at desc limit 20`;
    const tenders = await sql`select * from tenders where user_id = ${context.userId} order by created_at desc limit 20`;
    const routes = await sql`select * from routes where user_id = ${context.userId} order by created_at desc limit 20`;
    const audit = await sql`select * from audit_events where user_id = ${context.userId} order by created_at desc limit 30`;
    const counts = await sql<{
      contacts: number;
      open_tasks: number;
      pending_bookings: number;
      documents: number;
      ai_runs: number;
    }>`
      select
        (select count(*)::int from contacts where user_id = ${context.userId}) as contacts,
        (select count(*)::int from tasks where user_id = ${context.userId} and status = 'open') as open_tasks,
        (select count(*)::int from bookings where user_id = ${context.userId} and status = 'pending') as pending_bookings,
        (select count(*)::int from documents where user_id = ${context.userId}) as documents,
        (select count(*)::int from ai_runs where user_id = ${context.userId}) as ai_runs
    `;
    const c = counts[0];
    return {
      workspace: {
        companyName: ws[0]?.company_name ?? "My business",
        industry: ws[0]?.industry ?? "general",
        seeded: Boolean(ws[0]?.seeded),
      },
      contacts: contacts.map(mapContact),
      tasks: tasks.map(mapTask),
      bookings: bookings.map(mapBooking),
      documents: documents.map((r) => ({
        id: String(r.id),
        type: String(r.type),
        title: String(r.title),
        body: String(r.body),
        status: String(r.status),
        createdAt: String(r.created_at),
      })),
      opportunities: opportunities.map((r) => ({
        id: String(r.id),
        kind: String(r.kind),
        title: String(r.title),
        detail: (r.detail as string) ?? null,
        stage: String(r.stage),
        notes: (r.notes as string) ?? null,
        createdAt: String(r.created_at),
      })),
      tenders: tenders.map((r) => ({
        id: String(r.id),
        title: String(r.title),
        ref: (r.ref as string) ?? null,
        deadline: (r.deadline as string) ?? null,
        valueNote: (r.value_note as string) ?? null,
        requirements: (r.requirements as string) ?? null,
        analysis: (r.analysis as string) ?? null,
        status: String(r.status),
        createdAt: String(r.created_at),
      })),
      routes: routes.map((r) => ({
        id: String(r.id),
        operation: String(r.operation),
        vehicle: (r.vehicle as string) ?? null,
        startPoint: (r.start_point as string) ?? null,
        stops: (r.stops as string) ?? null,
        plan: (r.plan as string) ?? null,
        status: String(r.status),
        createdAt: String(r.created_at),
      })),
      audit: audit.map((r) => ({
        id: String(r.id),
        event: String(r.event),
        detail: (r.detail as string) ?? null,
        createdAt: String(r.created_at),
      })),
      counts: {
        contacts: Number(c?.contacts ?? 0),
        openTasks: Number(c?.open_tasks ?? 0),
        pendingBookings: Number(c?.pending_bookings ?? 0),
        documents: Number(c?.documents ?? 0),
        aiRuns: Number(c?.ai_runs ?? 0),
      },
    };
  });

export const seedWorkspace = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureWorkspace(context.userId);
    const already = await sql<{ seeded: boolean }>`
      select seeded from workspaces where user_id = ${context.userId}
    `;
    if (already[0]?.seeded) return { ok: true as const, already: true };

    const uid = context.userId;
    const now = () => crypto.randomUUID();

    await sql`update workspaces set company_name = ${"Northline Plant & Transport"}, industry = ${"transport"}, seeded = true where user_id = ${uid}`;

    const contacts: Array<[string, string, string, string, string, string, number, string]> = [
      [now(), "James Whitaker", "Whitaker Groundworks", "james@whitaker.example", "0161 000 1001", "8-ton excavator for a Manchester site next Tuesday", 55, "qualified"],
      [now(), "Priya Shah", "Northern Logistics", "priya@northern.example", "0161 000 1002", "Transport quote for three vehicles next Tuesday", 60, "new"],
      [now(), "Tom Brennan", "Brennan Facilities", "tom@brennan.example", "0161 000 1003", "Mini excavator for three days starting Monday", 50, "follow-up"],
    ];
    for (const [id, name, company, email, phone, need, score, status] of contacts) {
      await sql`insert into contacts (id, user_id, name, company, email, phone, need, source, score, status)
        values (${id}, ${uid}, ${name}, ${company}, ${email}, ${phone}, ${need}, ${"sample"}, ${score}, ${status})`;
    }

    await sql`insert into tasks (id, user_id, title, owner, due_date, status, priority, notes)
      values (${now()}, ${uid}, ${"Sales: follow up Priya Shah transport quote"}, ${"Sales Team"}, ${new Date().toISOString().slice(0, 10)}, ${"open"}, ${"high"}, ${"Three vehicles, Tuesday. Collect specification before pricing."})`;
    await sql`insert into tasks (id, user_id, title, owner, due_date, status, priority)
      values (${now()}, ${uid}, ${"Workshop: 8-ton excavator hydraulic check"}, ${"Workshop"}, ${new Date().toISOString().slice(0, 10)}, ${"open"}, ${"high"})`;
    await sql`insert into tasks (id, user_id, title, owner, due_date, status, priority)
      values (${now()}, ${uid}, ${"Tender: fleet insurance evidence pack"}, ${"Principal"}, ${""}, ${"open"}, ${"normal"})`;

    await sql`insert into bookings (id, user_id, contact_name, type, date, time, notes, status)
      values (${now()}, ${uid}, ${"James Whitaker"}, ${"Site meeting"}, ${"2026-09-01"}, ${"10:30"}, ${"45 minutes. Confirm address before locking the diary."}, ${"pending"})`;

    await sql`insert into documents (id, user_id, type, title, body, status)
      values (${now()}, ${uid}, ${"Proposal"}, ${"Whitaker Groundworks — hire proposal draft"}, ${"DRAFT — for internal review.\n\nPrepared for Whitaker Groundworks.\nRequirement: 8-ton excavator, Manchester site, next Tuesday.\nPrice: [PRICE TO BE CONFIRMED BY SALES]\nAvailability: [TO BE CONFIRMED BY OPERATIONS]\n\nThis document is a draft and must be approved before issue."}, ${"draft"})`;

    await sql`insert into tenders (id, user_id, title, ref, deadline, value_note, requirements, status)
      values (${now()}, ${uid}, ${"Local authority plant-hire framework"}, ${"LA-PH-26-04"}, ${"2026-09-04"}, ${"Not supplied"}, ${"Mobilisation plan, public liability, safeguarding, fleet list. ISO 45001 not held."}, ${"review"})`;

    await sql`insert into opportunities (id, user_id, kind, title, detail, stage)
      values (${now()}, ${uid}, ${"auto"}, ${"EV SUV enquiry — 20k miles, sub £650/month"}, ${"Fact-find incomplete. Do not quote a rate."}, ${"qualification"})`;
    await sql`insert into opportunities (id, user_id, kind, title, detail, stage)
      values (${now()}, ${uid}, ${"freshx"}, ${"PiQa Red — UK premium supermarket interest"}, ${"Grower pack incomplete. Certification not verified."}, ${"qualification"})`;

    await sql`insert into audit_events (id, user_id, event, detail)
      values (${now()}, ${uid}, ${"workspace.seeded"}, ${"Northline Plant & Transport sample records"})`;

    return { ok: true as const, already: false };
  });

const ContactIn = z.object({
  name: z.string().min(1).max(120),
  company: z.string().max(120).optional(),
  email: z.string().max(180).optional(),
  phone: z.string().max(40).optional(),
  need: z.string().max(2000).optional(),
  source: z.string().max(40).optional(),
});

export const addContact = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => ContactIn.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    const score = scoreEnquiry(data.need ?? "");
    await sql`insert into contacts (id, user_id, name, company, email, phone, need, source, score, status)
      values (${id}, ${context.userId}, ${data.name}, ${data.company ?? null}, ${data.email ?? null}, ${data.phone ?? null}, ${data.need ?? null}, ${data.source ?? "manual"}, ${score}, ${"new"})`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"contact.created"}, ${data.name})`;
    return { id, score };
  });

const TaskIn = z.object({
  title: z.string().min(1).max(200),
  owner: z.string().max(80).optional(),
  dueDate: z.string().max(20).optional(),
  priority: z.enum(["low", "normal", "high"]).optional(),
  notes: z.string().max(2000).optional(),
});

export const addTask = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => TaskIn.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into tasks (id, user_id, title, owner, due_date, status, priority, notes)
      values (${id}, ${context.userId}, ${data.title}, ${data.owner ?? "Team"}, ${data.dueDate ?? null}, ${"open"}, ${data.priority ?? "normal"}, ${data.notes ?? null})`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"task.created"}, ${data.title})`;
    return { id };
  });

export const setTaskStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ id: z.string(), status: z.enum(["open", "done"]) }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update tasks set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
    return { ok: true as const };
  });

const BookingIn = z.object({
  contactName: z.string().min(1).max(120),
  type: z.string().min(1).max(80),
  date: z.string().min(4).max(20),
  time: z.string().min(1).max(20),
  notes: z.string().max(2000).optional(),
});

export const addBooking = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => BookingIn.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into bookings (id, user_id, contact_name, type, date, time, notes, status)
      values (${id}, ${context.userId}, ${data.contactName}, ${data.type}, ${data.date}, ${data.time}, ${data.notes ?? null}, ${"pending"})`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"booking.prepared"}, ${data.contactName})`;
    return { id };
  });

export const setBookingStatus = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        id: z.string(),
        status: z.enum(["pending", "confirmed", "cancelled"]),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await sql`update bookings set status = ${data.status} where id = ${data.id} and user_id = ${context.userId}`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"booking." + data.status}, ${data.id})`;
    return { ok: true as const };
  });

const DocIn = z.object({
  type: z.string().min(1).max(80),
  title: z.string().min(1).max(180),
  body: z.string().min(1).max(20000),
});

export const saveDocument = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => DocIn.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into documents (id, user_id, type, title, body, status)
      values (${id}, ${context.userId}, ${data.type}, ${data.title}, ${data.body}, ${"draft"})`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"document.saved"}, ${data.title})`;
    return { id };
  });

const RouteIn = z.object({
  operation: z.string().min(1).max(80),
  vehicle: z.string().max(80).optional(),
  startPoint: z.string().min(1).max(200),
  stops: z.string().min(1).max(4000),
  plan: z.string().max(20000).optional(),
});

export const saveRoute = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => RouteIn.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into routes (id, user_id, operation, vehicle, start_point, stops, plan, status)
      values (${id}, ${context.userId}, ${data.operation}, ${data.vehicle ?? null}, ${data.startPoint}, ${data.stops}, ${data.plan ?? null}, ${"draft"})`;
    return { id };
  });

const OppIn = z.object({
  kind: z.enum(["auto", "freshx"]),
  title: z.string().min(1).max(180),
  detail: z.string().max(4000).optional(),
});

export const saveOpportunity = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => OppIn.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into opportunities (id, user_id, kind, title, detail, stage)
      values (${id}, ${context.userId}, ${data.kind}, ${data.title}, ${data.detail ?? null}, ${"qualification"})`;
    return { id };
  });

const TenderIn = z.object({
  title: z.string().min(1).max(180),
  ref: z.string().max(80).optional(),
  deadline: z.string().max(20).optional(),
  requirements: z.string().max(8000).optional(),
  analysis: z.string().max(20000).optional(),
});

export const saveTender = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => TenderIn.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`insert into tenders (id, user_id, title, ref, deadline, requirements, analysis, status)
      values (${id}, ${context.userId}, ${data.title}, ${data.ref ?? null}, ${data.deadline ?? null}, ${data.requirements ?? null}, ${data.analysis ?? null}, ${"review"})`;
    return { id };
  });

export const captureEnquiry = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        name: z.string().min(1).max(120),
        contact: z.string().max(180).optional(),
        text: z.string().min(1).max(4000),
        taskTitle: z.string().max(200).optional(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const cid = crypto.randomUUID();
    const tid = crypto.randomUUID();
    const score = scoreEnquiry(data.text);
    await sql`insert into contacts (id, user_id, name, company, email, phone, need, source, score, status)
      values (${cid}, ${context.userId}, ${data.name}, ${null}, ${data.contact ?? null}, ${null}, ${data.text}, ${"Receptionist"}, ${score}, ${"new"})`;
    const title = data.taskTitle || `Follow up ${data.name}`;
    await sql`insert into tasks (id, user_id, title, owner, due_date, status, priority, notes)
      values (${tid}, ${context.userId}, ${title}, ${"Reception Team"}, ${new Date().toISOString().slice(0, 10)}, ${"open"}, ${score >= 50 ? "high" : "normal"}, ${data.text.slice(0, 500)})`;
    await sql`insert into audit_events (id, user_id, event, detail)
      values (${crypto.randomUUID()}, ${context.userId}, ${"reception.captured"}, ${data.name})`;
    return { contactId: cid, taskId: tid, score };
  });
