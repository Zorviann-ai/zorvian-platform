const NODES = [
  { label: "Reception", className: "top-[6%] left-[38%]" },
  { label: "Calendar", className: "top-[18%] right-[2%]" },
  { label: "Booking", className: "top-[46%] right-[-2%]" },
  { label: "Leads", className: "bottom-[14%] right-[8%]" },
  { label: "Social", className: "bottom-[2%] left-[36%]" },
  { label: "Marketing", className: "bottom-[16%] left-[2%]" },
  { label: "Sales", className: "top-[46%] left-[-2%]" },
  { label: "Guardian", className: "top-[16%] left-[4%]" },
];

export function Orbit() {
  return (
    <div className="relative mx-auto grid min-h-[520px] w-full max-w-[540px] place-items-center">
      <div className="absolute size-[470px] rounded-full border border-gold/25 shadow-[0_0_120px_rgba(201,162,74,0.08)]" />
      <div className="absolute size-[325px] rounded-full border border-dashed border-gold/20" />
      <div className="absolute size-[210px] rounded-full border border-white/10" />
      <div className="relative z-10 grid size-[190px] place-items-center rounded-full border border-gold/30 bg-[radial-gradient(circle,#17130a,#070707_68%)] shadow-[0_25px_80px_rgba(201,162,74,0.18)]">
        <img src="/brand/seal.png" alt="Caelomere" className="size-[145px] rounded-full object-cover" />
      </div>
      {NODES.map((n) => (
        <div
          key={n.label}
          className={`absolute z-10 border border-gold/25 bg-black/85 px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.12em] text-paper ${n.className}`}
        >
          {n.label}
        </div>
      ))}
    </div>
  );
}
