import { useMemo, useRef, useState } from "react";
import type { Scene } from "@/data/library";
import type { Teller } from "@/data/tellers";
import { tellTheStory, speakTelling } from "@/lib/server/studios";

export type BookData = {
  slug: string;
  title: string;
  author: string;
  year: number;
  licence: string;
  chapters: {
    id: string;
    n: number;
    title: string;
    excerpt: string;
    paragraphs: string[];
  }[];
};

export function Cinema({
  book,
  scenes,
  tellers,
}: {
  book: BookData;
  scenes: Record<number, Scene>;
  tellers: Teller[];
}) {
  const [n, setN] = useState(1);
  const [lit, setLit] = useState<number | null>(0);
  const [playing, setPlaying] = useState(true);
  const [tellerId, setTellerId] = useState(tellers[0]?.id ?? "alice");
  const [telling, setTelling] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [mode, setMode] = useState<"carroll" | "teller">("carroll");
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const chapter = useMemo(
    () => book.chapters.find((c) => c.n === n) ?? book.chapters[0],
    [book.chapters, n],
  );
  const scene = scenes[n] ?? {
    still: "/lanterna/library.jpg",
    caption: chapter.title,
  };
  const teller = tellers.find((t) => t.id === tellerId) ?? tellers[0];
  const litText = lit != null ? chapter.paragraphs[lit] : null;

  async function letThemTell() {
    if (!teller) return;
    setBusy(true);
    setError("");
    try {
      const passage = (litText ? litText + "\n\n" : "") + chapter.paragraphs.join("\n\n");
      const result = await tellTheStory({
        data: {
          tellerId: teller.id,
          bookTitle: book.title,
          chapterTitle: chapter.title,
          passage: passage.slice(0, 5500),
        },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setTelling(result.telling);
      setMode("teller");
      const spoken = await speakTelling({
        data: { text: result.telling.slice(0, 480), voice: result.voice },
      });
      if (spoken.ok) {
        const url = `data:${spoken.mime};base64,${spoken.audio}`;
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current.src = "";
        }
        const audio = new Audio(url);
        audioRef.current = audio;
        void audio.play().catch(() => undefined);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "The studio could not tell it.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="pb-16">
      <section className="relative min-h-[70dvh] overflow-hidden bg-black">
        {playing && scene.film ? (
          <video
            key={scene.film}
            className="absolute inset-0 h-full w-full object-cover"
            src={scene.film}
            autoPlay
            muted
            loop
            playsInline
            poster={scene.still}
          />
        ) : (
          <img src={scene.still} alt="" className="absolute inset-0 h-full w-full object-cover" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-[color:var(--ln-ink)] via-black/30 to-black/25" />
        <div className="ln-grain" />
        <div className="relative flex min-h-[70dvh] flex-col justify-end px-5 pb-10 md:px-12">
          <p className="text-[11px] font-semibold uppercase tracking-[0.28em] text-[color:var(--ln-gold)]">
            Caelomere Studios · {book.author} · {book.year}
          </p>
          <h1 className="mt-3 max-w-4xl text-[clamp(2.2rem,6vw,4.6rem)] leading-[0.95]">
            {book.title}
          </h1>
          <p className="mt-4 max-w-xl text-sm leading-6 text-[color:var(--ln-paper)]/80">
            {scene.caption} Choose who tells it. Carroll’s text stays on the page.
          </p>
          {scene.film ? (
            <button
              type="button"
              className="mt-6 w-fit border border-[color:var(--ln-gold)] px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-[color:var(--ln-gold)]"
              onClick={() => setPlaying((p) => !p)}
            >
              {playing ? "Hold the frame" : "Play the moving picture"}
            </button>
          ) : null}
        </div>
      </section>

      <section className="border-b border-[color:var(--ln-gold)]/20 px-5 py-6 md:px-12">
        <p className="text-[11px] font-semibold uppercase tracking-[0.22em] text-[color:var(--ln-gold)]">
          Storyteller
        </p>
        <p className="mt-1 text-sm text-[color:var(--ln-muted)]">
          Any character may tell this chapter. The picture stays. The voice changes.
        </p>
        <div className="mt-4 flex gap-3 overflow-x-auto pb-2">
          {tellers.map((t) => {
            const on = t.id === tellerId;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  setTellerId(t.id);
                  setTelling("");
                }}
                className={`w-28 shrink-0 text-left ${on ? "opacity-100" : "opacity-60 hover:opacity-100"}`}
              >
                <img src={t.portrait} alt="" className="aspect-[3/4] w-full object-cover" />
                <span className="mt-2 block font-display text-sm leading-tight">{t.name}</span>
                <span className="block text-[10px] uppercase tracking-[0.12em] text-[color:var(--ln-gold)]">
                  {t.role}
                </span>
              </button>
            );
          })}
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={busy}
            onClick={() => void letThemTell()}
            className="border border-[color:var(--ln-gold)] bg-[color:var(--ln-gold)] px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-[color:var(--ln-ink)] disabled:opacity-50"
          >
            {busy ? `${teller?.name} is speaking…` : `Let ${teller?.name} tell it`}
          </button>
          {telling ? (
            <button
              type="button"
              className="border border-[color:var(--ln-gold)]/40 px-4 py-2.5 text-[11px] uppercase tracking-[0.16em]"
              onClick={() => setMode(mode === "teller" ? "carroll" : "teller")}
            >
              {mode === "teller" ? "Show Carroll’s text" : "Show this telling"}
            </button>
          ) : null}
        </div>
        {error ? <p className="mt-3 text-sm text-[#d4785a]">{error}</p> : null}
      </section>

      <div className="flex gap-3 overflow-x-auto px-5 py-6 md:px-12">
        {book.chapters.map((c) => {
          const still = scenes[c.n]?.still ?? "/lanterna/library.jpg";
          const on = c.n === n;
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => {
                setN(c.n);
                setLit(0);
                setPlaying(true);
                setTelling("");
                setMode("carroll");
              }}
              className={`w-40 shrink-0 text-left ${on ? "opacity-100" : "opacity-65 hover:opacity-100"}`}
            >
              <img src={still} alt="" className="aspect-video w-full object-cover" />
              <span className="mt-2 block text-[10px] uppercase tracking-[0.14em] text-[color:var(--ln-gold)]">
                {String(c.n).padStart(2, "0")}
                {scenes[c.n]?.film ? " · film" : ""}
              </span>
              <span className="block font-display text-sm leading-tight">
                {c.title.replace(/^CHAPTER [IVX]+\.\s*/, "")}
              </span>
            </button>
          );
        })}
      </div>

      <article className="mx-auto grid max-w-6xl gap-10 px-5 md:grid-cols-[1.15fr_0.85fr] md:px-12">
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-[color:var(--ln-gold)]">
            {mode === "teller" && teller ? `${teller.name} tells` : chapter.title}
          </p>
          {mode === "teller" && telling ? (
            <div className="mt-6 whitespace-pre-wrap font-display text-[1.12rem] leading-[1.75] text-[color:var(--ln-paper)]/90">
              {telling}
            </div>
          ) : (
            <div className="mt-6 space-y-2 font-display text-[1.12rem] leading-[1.75] text-[color:var(--ln-paper)]/90">
              {chapter.paragraphs.map((p, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setLit(i)}
                  className={`block w-full rounded-sm px-3 py-3 text-left transition ${
                    lit === i
                      ? "bg-[color:var(--ln-gold)]/15 text-[color:var(--ln-paper)]"
                      : "hover:bg-white/5"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          )}
          <div className="mt-10 flex gap-3">
            <button
              type="button"
              disabled={n <= 1}
              className="border border-[color:var(--ln-gold)]/40 px-4 py-2 text-[11px] uppercase tracking-[0.16em] disabled:opacity-30"
              onClick={() => setN((x) => Math.max(1, x - 1))}
            >
              Previous
            </button>
            <button
              type="button"
              disabled={n >= book.chapters.length}
              className="border border-[color:var(--ln-gold)] px-4 py-2 text-[11px] uppercase tracking-[0.16em] text-[color:var(--ln-gold)] disabled:opacity-30"
              onClick={() => setN((x) => Math.min(book.chapters.length, x + 1))}
            >
              Next chapter
            </button>
          </div>
        </div>
        <aside className="md:sticky md:top-8 md:self-start">
          <img
            src={teller?.portrait ?? scene.still}
            alt={teller?.name ?? scene.caption}
            className="w-full object-cover"
          />
          <p className="mt-3 font-display text-xl">{teller?.name}</p>
          <p className="text-sm text-[color:var(--ln-muted)]">{scene.caption}</p>
          {litText && mode === "carroll" ? (
            <blockquote className="mt-5 border-l-2 border-[color:var(--ln-gold)] pl-4 font-display text-[1.05rem] leading-7 text-[color:var(--ln-paper)]">
              {litText}
            </blockquote>
          ) : null}
          <p className="mt-6 text-xs leading-5 text-[color:var(--ln-muted)]">{book.licence}</p>
        </aside>
      </article>
    </main>
  );
}
