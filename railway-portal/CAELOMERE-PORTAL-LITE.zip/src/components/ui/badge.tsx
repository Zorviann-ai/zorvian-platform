import { cn } from "@/lib/utils";

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: React.ReactNode;
  tone?: "neutral" | "live" | "build" | "gold" | "danger";
  className?: string;
}) {
  const tones = {
    neutral: "bg-line/60 text-muted",
    live: "bg-success/12 text-success",
    build: "bg-gold/18 text-warn",
    gold: "bg-gold text-ink",
    danger: "bg-danger/12 text-danger",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.08em]",
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}
