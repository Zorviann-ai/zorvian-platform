import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes } from "react";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-semibold tracking-wide transition-transform duration-150 ease-out disabled:opacity-55 disabled:cursor-not-allowed active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-gold",
  {
    variants: {
      variant: {
        gold: "bg-gold text-ink hover:bg-gold-2",
        ink: "bg-ink text-paper hover:bg-ink-2",
        ghost:
          "bg-transparent text-fg border border-line hover:border-muted",
        darkghost:
          "bg-transparent text-paper border border-line-dark hover:border-gold",
        danger: "bg-danger text-paper",
      },
      size: {
        sm: "h-10 px-3 text-xs rounded-sm",
        md: "h-11 px-4 text-sm rounded-md",
        lg: "h-12 px-5 text-sm rounded-md",
      },
    },
    defaultVariants: { variant: "gold", size: "md" },
  },
);

export function Button({
  className,
  variant,
  size,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants>) {
  return (
    <button
      className={cn(buttonVariants({ variant, size }), className)}
      {...props}
    />
  );
}
