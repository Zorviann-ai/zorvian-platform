import { cn } from "@/lib/utils";

export function Wordmark({
  className,
  light = false,
  size = 48,
}: {
  className?: string;
  light?: boolean;
  size?: number;
}) {
  return (
    <img
      src="/brand/seal-128.png"
      alt="Caelomere"
      width={size}
      height={size}
      className={cn("rounded-full object-cover", className)}
      style={{ width: size, height: size }}
    />
  );
}

export function Mark({ className, size = 32 }: { className?: string; size?: number }) {
  return (
    <img
      src="/brand/seal-64.png"
      alt="Caelomere"
      width={size}
      height={size}
      className={cn("rounded-full object-cover", className)}
      style={{ width: size, height: size }}
    />
  );
}

export function Seal({ className, size = 160 }: { className?: string; size?: number }) {
  return (
    <img
      src="/brand/seal.png"
      alt="Caelomere"
      width={size}
      height={size}
      className={cn("rounded-full object-cover", className)}
      style={{ width: size, height: size }}
    />
  );
}
