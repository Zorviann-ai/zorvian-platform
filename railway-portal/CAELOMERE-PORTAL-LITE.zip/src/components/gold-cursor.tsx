import { useEffect, useRef } from "react";

export function GoldCursor() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia("(pointer: coarse), (prefers-reduced-motion: reduce)").matches) {
      el.style.display = "none";
      return;
    }
    const move = (e: MouseEvent) => {
      el.style.transform = `translate(${e.clientX - 14}px, ${e.clientY - 14}px)`;
    };
    window.addEventListener("mousemove", move, { passive: true });
    return () => window.removeEventListener("mousemove", move);
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden
      className="pointer-events-none fixed left-0 top-0 z-[70] hidden size-7 rounded-full border border-gold/70 mix-blend-screen md:block"
      style={{ boxShadow: "0 0 24px rgba(201,162,74,0.45)" }}
    />
  );
}
