import { useState } from "react";
import { runIntelligence } from "@/lib/server/ai";
import type { ModuleDef } from "@/lib/modules";
import { Button } from "@/components/ui/button";
import { Field, Textarea } from "@/components/ui/field";

export function AiPanel({
  module,
  onReply,
  extra,
}: {
  module: ModuleDef;
  onReply?: (reply: string, prompt: string) => void;
  extra?: React.ReactNode;
}) {
  const [prompt, setPrompt] = useState("");
  const [reply, setReply] = useState("");
  const [applied, setApplied] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  async function run() {
    const message = prompt.trim();
    if (!message) return;
    setBusy(true);
    setError("");
    setReply("");
    setApplied([]);
    try {
      const result = await runIntelligence({
        data: { tool: module.id, message },
      });
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setReply(result.reply);
      setApplied(result.applied ?? []);
      onReply?.(result.reply, message);
    } catch (e) {
      setError(e instanceof Error ? e.message : "The request failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1.4fr)_minmax(240px,0.8fr)]">
      <div className="rounded-lg border border-line bg-card p-5">
        <h3 className="font-display text-lg font-semibold">{module.title}</h3>
        {extra}
        <Field label="Brief" htmlFor={`${module.id}-input`} className="mt-4">
          <Textarea
            id={`${module.id}-input`}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder={module.placeholder}
          />
        </Field>
        {module.presets.length > 0 && (
          <div className="mb-4 flex flex-wrap gap-2">
            {module.presets.map((p) => (
              <button
                key={p}
                type="button"
                className="rounded-full border border-line px-3 py-2 text-left text-xs text-muted hover:border-gold hover:text-fg"
                onClick={() => setPrompt(p)}
              >
                {p}
              </button>
            ))}
          </div>
        )}
        <Button type="button" onClick={() => void run()} disabled={busy}>
          {busy ? "Working…" : module.button}
        </Button>
        {applied.length > 0 && (
          <ul className="mt-3 space-y-1 text-xs text-gold">
            {applied.map((a) => (
              <li key={a}>Saved · {a}</li>
            ))}
          </ul>
        )}
        <div className="mt-4 min-h-24 whitespace-pre-wrap rounded-md border border-line bg-paper px-4 py-3 text-sm leading-relaxed">
          {error ? (
            <span className="text-danger">{error}</span>
          ) : reply ? (
            reply
          ) : (
            <span className="text-muted">
              Enter information to begin. Outputs are prepared as records — they are
              not sent, booked or published until you approve.
            </span>
          )}
        </div>
      </div>
      <div className="rounded-lg border border-line bg-card p-5">
        <h3 className="font-display text-lg font-semibold">Controls</h3>
        <ul className="mt-3 divide-y divide-line">
          {module.caps.map(([t, d]) => (
            <li key={t} className="py-3">
              <strong className="block text-sm">{t}</strong>
              <span className="text-xs leading-relaxed text-muted">{d}</span>
            </li>
          ))}
        </ul>
        <p className="mt-4 border-l-4 border-gold bg-gold/10 px-3 py-3 text-xs leading-relaxed text-warn">
          Guardian: consequential actions require a person. Caelomere will not
          invent prices, availability, accreditations or live traffic.
        </p>
      </div>
    </div>
  );
}
