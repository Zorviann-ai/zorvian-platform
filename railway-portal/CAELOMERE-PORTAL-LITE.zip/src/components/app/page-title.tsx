import { Link } from "@tanstack/react-router";

export function PageTitle({
  title,
  action,
}: {
  title: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-[22px] font-semibold text-fg">{title}</h1>
        <nav className="mt-1 flex items-center gap-2 text-xs text-muted">
          <Link to="/app" className="hover:text-fg">
            Home
          </Link>
          <span>/</span>
          <span className="text-fg">{title}</span>
        </nav>
      </div>
      {action}
    </div>
  );
}

export function PortalCard({
  title,
  action,
  children,
  className = "",
}: {
  title?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section className={`overflow-hidden rounded-md border border-[#ebe6dc] bg-white shadow-[0_0_20px_rgba(10,10,10,0.04)] ${className}`}>
      {title ? (
        <header className="flex items-center justify-between border-b border-[#f0ebe3] px-5 py-3.5">
          <h2 className="text-[15px] font-semibold">{title}</h2>
          {action}
        </header>
      ) : null}
      <div className="p-5">{children}</div>
    </section>
  );
}

export function StatCard({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <section className="rounded-md border border-[#ebe6dc] bg-white p-4 shadow-[0_0_20px_rgba(10,10,10,0.04)]">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-[12px] font-medium text-muted">{label}</p>
          <p className="mt-1 text-[26px] font-semibold tabular-nums leading-none">{value}</p>
          {hint ? <p className="mt-2 text-[11px] text-muted">{hint}</p> : null}
        </div>
        <span className="grid size-10 place-items-center rounded-md bg-ink text-[11px] font-bold text-gold">
          C
        </span>
      </div>
    </section>
  );
}
