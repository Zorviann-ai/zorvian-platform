import { useRef, useState } from "react";
import { talkToCora, speakText } from "@/lib/server/ai";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/field";
import { Mic, Volume2 } from "lucide-react";

type SpeechRec = {
  start: () => void;
  stop: () => void;
  onresult: ((ev: { results: { 0: { 0: { transcript: string } } } }) => void) | null;
  onend: (() => void) | null;
  lang: string;
  interimResults: boolean;
};

function getRecognizer(): SpeechRec | null {
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRec;
    webkitSpeechRecognition?: new () => SpeechRec;
  };
  const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
  if (!Ctor) return null;
  const rec = new Ctor();
  rec.lang = "en-GB";
  rec.interimResults = false;
  return rec;
}

async function playAudio(base64: string, mime: string) {
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const url = URL.createObjectURL(new Blob([bytes], { type: mime }));
  const audio = new Audio(url);
  await audio.play();
}

function speakBrowser(text: string) {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = "en-GB";
  u.rate = 0.96;
  const voices = window.speechSynthesis.getVoices();
  const gb = voices.find((v) => /en-GB/i.test(v.lang) && /female|woman|samantha|moira|serena/i.test(v.name))
    || voices.find((v) => /en-GB/i.test(v.lang));
  if (gb) u.voice = gb;
  window.speechSynthesis.speak(u);
}

export function Secretary({
  onRefresh,
  compact = false,
}: {
  onRefresh: () => void;
  compact?: boolean;
}) {
  const [message, setMessage] = useState("");
  const [speak, setSpeak] = useState("Good morning. I am Cora. Tell me who called and what they need.");
  const [brief, setBrief] = useState("");
  const [applied, setApplied] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [listening, setListening] = useState(false);
  const [voiceOn, setVoiceOn] = useState(true);
  const recRef = useRef<SpeechRec | null>(null);

  async function voiceOut(text: string) {
    if (!voiceOn) return;
    try {
      const result = await speakText({ data: { text, voice: "eve" } });
      if (result.ok) {
        await playAudio(result.audio, result.mime);
        return;
      }
    } catch {
      /* fall through */
    }
    speakBrowser(text);
  }

  async function send(text?: string) {
    const input = (text ?? message).trim();
    if (!input) return;
    setBusy(true);
    try {
      const result = await talkToCora({ data: { message: input } });
      if (!result.ok) {
        setBrief(result.error);
        return;
      }
      setSpeak(result.speak);
      setBrief(result.brief);
      setApplied(result.applied);
      setMessage("");
      onRefresh();
      void voiceOut(result.speak);
    } finally {
      setBusy(false);
    }
  }

  function listen() {
    const rec = getRecognizer();
    if (!rec) {
      setBrief("Microphone dictation is not available in this browser. Type the instruction instead.");
      return;
    }
    recRef.current = rec;
    rec.onresult = (ev) => {
      const t = ev.results[0][0].transcript;
      setMessage(t);
      void send(t);
    };
    rec.onend = () => setListening(false);
    setListening(true);
    rec.start();
  }

  return (
    <section className={compact ? "" : "overflow-hidden rounded-xl bg-ink text-paper shadow-soft"}>
      <div className={compact ? "grid gap-5 md:grid-cols-[200px_1fr]" : "grid gap-0 md:grid-cols-[240px_1fr]"}>
        <div className="relative bg-ink-2">
          <img
            src="/brand/cora.jpg"
            alt="Cora, Caelomere secretary"
            className="h-full min-h-56 w-full object-cover"
          />
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink to-transparent p-4">
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gold">Secretary</p>
            <p className="font-display text-2xl">Cora</p>
          </div>
        </div>
        <div className="p-5 md:p-6">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h2 className="font-display text-2xl">Speak to the business.</h2>
              <p className="mt-1 text-sm text-paper/65">
                Cora listens, prepares work, briefs specialists and asks for approval before anything leaves the company.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setVoiceOn((v) => !v)}
              className="grid size-10 place-items-center rounded-full border border-line-dark text-gold"
              aria-label={voiceOn ? "Mute Cora" : "Unmute Cora"}
            >
              <Volume2 className={voiceOn ? "size-4" : "size-4 opacity-40"} />
            </button>
          </div>
          <p className="mt-4 border-l-2 border-gold pl-3 text-sm italic text-paper/80">“{speak}”</p>
          <div className="mt-4 flex gap-2">
            <Textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Find overdue follow-ups. Book James for Tuesday afternoon. Qualify this enquiry…"
              className="min-h-24 border-line-dark bg-ink-3 text-paper placeholder:text-paper/35"
            />
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            {[
              "James Whitaker called. He wants a quote for two vans next Tuesday in Manchester. Book a call tomorrow at 10:00.",
              "Draft a follow-up letter to James confirming we have his enquiry and will not quote a price until sales review it.",
            ].map((starter) => (
              <button
                key={starter}
                type="button"
                className="max-w-full rounded-full border border-line-dark px-3 py-1.5 text-left text-[11px] text-paper/70 hover:border-gold hover:text-gold"
                onClick={() => {
                  setMessage(starter);
                  void send(starter);
                }}
              >
                Try: {starter.slice(0, 52)}…
              </button>
            ))}
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Button type="button" disabled={busy} onClick={() => void send()}>
              {busy ? "Cora is working…" : "Instruct Cora"}
            </Button>
            <Button
              type="button"
              variant="darkghost"
              disabled={busy}
              onClick={listen}
            >
              <Mic className="size-4" />
              {listening ? "Listening…" : "Speak"}
            </Button>
          </div>
          {applied.length > 0 && (
            <ul className="mt-4 space-y-1 text-xs text-gold">
              {applied.map((a) => (
                <li key={a}>Prepared · {a}</li>
              ))}
            </ul>
          )}
          {brief ? (
            <pre className="mt-4 max-h-56 overflow-auto whitespace-pre-wrap rounded-md bg-ink-3 p-3 text-xs leading-relaxed text-paper/75">
              {brief}
            </pre>
          ) : null}
        </div>
      </div>
    </section>
  );
}
