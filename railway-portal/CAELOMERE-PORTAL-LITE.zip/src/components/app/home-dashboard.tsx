import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { runIntelligence } from "@/lib/server/ai";
import { seedWorkspace, type Dashboard } from "@/lib/server/workspace";
import { MODULES } from "@/lib/modules";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/field";
import { Badge } from "@/components/ui/badge";

export function HomeDashboard({
  data,
  onRefresh,
}: {
  data: Dashboard;
  onRefresh: () => void;
}) {
  const [command, setCommand] = useState("");
  const [reply, setReply] = useState("");
  const [busy, setBusy] = useState(false);
  const [seeding, setSeeding] = useState(false);

  async function ask() {
    const message = command.trim();
    if (!message) return;
    setBusy(true);
    setReply("");
    try {
      const result = await runIntelligence({ data: { tool: "ask", message } });
      setReply(result.ok ? result.reply : result.error);
    } catch (e) {
      setReply(e instanceof Error ? e.message : "The request failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <section className="rounded-xl bg-ink p-6 text-paper shadow-soft md:p-8">
        <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-gold">
          Zorvian AI
        </p>
        <h1 className="mt-1 font-display text-3xl font-semibold md:text-4xl">
          Business control.
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-paper/65">
          Ask Zorvian a question, prepare work, qualify customers or open a
          specialist tool. {data.workspace.companyName} is your workspace.
        </p>
        <div className="mt-5 flex flex-col gap-2 sm:flex-row">
          <Input
            value={command}
            onChange={(e) => setCommand(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") void ask();
            }}
            placeholder="Ask Zorvian anything about your business"
            className="h-12 flex-1 border-0 bg-paper-2"
          />
          <Button
            type="button"
            size="lg"
            onClick={() => void ask()}
            disabled={busy}
          >
            {busy ? "Working…" : "Ask Zorvian"}
          </Button>
        </div>
        {reply ? (
          <pre className="mt-4 max-h-64 overflow-auto whitespace-pre-wrap rounded-md bg-ink-2 p-4 text-xs leading-relaxed text-paper/80">
            {reply}
          </pre>
        ) : null}
      </section>

      {!data.workspace.seeded && (
        <div className="mt-5 flex flex-col gap-3 rounded-lg border border-gold/40 bg-gold/10 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <strong className="block text-sm">Load a sample company</strong>
            <p className="text-xs text-muted">
              Northline Plant & Transport — leads, tasks, a booking and a tender
              so the workspace is not empty.
            </p>
          </div>
          <Button
            type="button"
            disabled={seeding}
            onClick={async () => {
              setSeeding(true);
              try {
                await seedWorkspace();
                onRefresh();
              } finally {
                setSeeding(false);
              }
            }}
          >
            {seeding ? "Loading…" : "Load sample data"}
          </Button>
        </div>
      )}

      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          [String(data.counts.contacts), "Leads & contacts"],
          [String(data.counts.openTasks), "Open tasks"],
          [String(data.counts.pendingBookings), "Pending bookings"],
          [String(data.counts.aiRuns), "AI runs"],
        ].map(([n, l]) => (
          <div
            key={l}
            className="rounded-lg border border-line bg-card px-5 py-4"
          >
            <strong className="block font-display text-3xl tabular-nums">
              {n}
            </strong>
            <span className="text-xs text-muted">{l}</span>
          </div>
        ))}
      </div>

      <div className="mt-8 flex items-end justify-between">
        <h2 className="font-display text-xl font-semibold">AI business tools</h2>
        <span className="text-xs text-muted">Choose an area to work on</span>
      </div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {MODULES.filter((m) => m.id !== "guardian").map((m) => (
          <Link
            key={m.id}
            to="/app/$module"
            params={{ module: m.id }}
            className="min-h-36 rounded-lg border border-line bg-card p-5 text-left transition-transform duration-150 hover:-translate-y-0.5 hover:shadow-soft"
          >
            <span className="inline-flex size-8 items-center justify-center rounded-sm bg-gold/20 text-xs font-bold text-warn">
              {m.n}
            </span>
            <h3 className="mt-3 font-display text-base font-semibold">
              {m.title}
            </h3>
            <p className="mt-1 text-xs leading-relaxed text-muted">{m.desc}</p>
          </Link>
        ))}
      </div>

      <div className="mt-8 grid gap-4 lg:grid-cols-2">
        <div className="rounded-lg border border-line bg-card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold">Open tasks</h3>
            <Badge tone="build">{data.counts.openTasks} open</Badge>
          </div>
          {data.tasks.filter((t) => t.status === "open").length === 0 ? (
            <p className="text-sm text-muted">No open tasks yet.</p>
          ) : (
            <ul className="divide-y divide-line">
              {data.tasks
                .filter((t) => t.status === "open")
                .slice(0, 5)
                .map((t) => (
                  <li key={t.id} className="py-3">
                    <strong className="block text-sm">{t.title}</strong>
                    <span className="text-xs text-muted">
                      {t.owner ?? "Team"}
                      {t.dueDate ? ` · ${t.dueDate}` : ""}
                    </span>
                  </li>
                ))}
            </ul>
          )}
        </div>
        <div className="rounded-lg border border-line bg-card p-5">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold">Latest leads</h3>
            <Badge>{data.counts.contacts} total</Badge>
          </div>
          {data.contacts.length === 0 ? (
            <p className="text-sm text-muted">
              No leads yet. Run the receptionist on an enquiry.
            </p>
          ) : (
            <ul className="divide-y divide-line">
              {data.contacts.slice(0, 5).map((c) => (
                <li key={c.id} className="py-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <strong className="block text-sm">{c.name}</strong>
                      <span className="text-xs text-muted">
                        {c.need?.slice(0, 80) || c.company || c.source}
                      </span>
                    </div>
                    <span className="text-xs font-bold tabular-nums text-warn">
                      {c.score}
                    </span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
