import { createContext, useContext } from "react";
import type { Dashboard } from "@/lib/server/workspace";
import type { getCrm } from "@/lib/server/crm";

export type CrmData = Awaited<ReturnType<typeof getCrm>>;

type Ctx = {
  data: Dashboard | null;
  crm: CrmData | null;
  loading: boolean;
  refresh: () => Promise<void>;
};

const C = createContext<Ctx | null>(null);

export function WorkspaceProvider({
  value,
  children,
}: {
  value: Ctx;
  children: React.ReactNode;
}) {
  return <C.Provider value={value}>{children}</C.Provider>;
}

export function useWorkspace() {
  const v = useContext(C);
  if (!v) throw new Error("WorkspaceProvider missing");
  return v;
}
