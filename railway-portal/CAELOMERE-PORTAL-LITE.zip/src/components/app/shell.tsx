import { Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useState } from "react";
import { signOut } from "@/lib/auth/client";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { MODULES } from "@/lib/modules";
import { Wordmark } from "@/components/brand";
import { cn } from "@/lib/utils";
import { useWorkspace } from "@/components/app/workspace-context";
import {
  Bell,
  CalendarDays,
  FileText,
  Home,
  Landmark,
  Menu,
  MessageSquare,
  Search,
  Settings,
  Shield,
  Store,
  Users,
  Wallet,
  X,
} from "lucide-react";

const PRIMARY = [
  { to: "/app", label: "Cora", exact: true, icon: Home },
  { to: "/app/crm", label: "CRM", icon: Users },
  { to: "/app/work", label: "Work", icon: CalendarDays },
  { to: "/app/documents", label: "Documents", icon: FileText },
  { to: "/app/marketing", label: "Marketing", icon: Store },
  { to: "/app/finance", label: "Finance", icon: Wallet },
  { to: "/app/comms", label: "Communications", icon: MessageSquare },
  { to: "/app/approvals", label: "Approvals", icon: Landmark },
  { to: "/app/guardian", label: "Guardian", icon: Shield },
  { to: "/app/settings", label: "Settings", icon: Settings },
] as const;

export function AppShell({ companyName }: { companyName: string }) {
  const user = useCurrentUser();
  const { crm } = useWorkspace();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const [q, setQ] = useState("");
  const [notesOpen, setNotesOpen] = useState(false);
  const label = user?.displayName ?? user?.primaryEmail ?? "Account";
  const pending = crm?.approvals.filter((a) => a.status === "pending") ?? [];

  function active(to: string, exact?: boolean) {
    if (exact) return pathname === to;
    return pathname === to || pathname.startsWith(`${to}/`);
  }

  return (
    <div className="min-h-dvh bg-[#f3efe6]">
      <div className="flex min-h-dvh">
        <aside
          className={cn(
            "z-30 flex w-[260px] shrink-0 flex-col bg-ink text-paper",
            open ? "fixed inset-y-0 left-0 md:static" : "hidden md:flex",
          )}
        >
          <div className="flex h-[70px] items-center justify-between border-b border-white/10 px-4">
            <Link to="/app" onClick={() => setOpen(false)} className="flex items-center">
              <Wordmark light size={48} />
            </Link>
            <button
              type="button"
              className="grid size-9 place-items-center md:hidden"
              aria-label="Close menu"
              onClick={() => setOpen(false)}
            >
              <X className="size-4" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto px-3 py-4">
            <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-paper/40">
              Your company
            </p>
            <nav className="flex flex-col gap-0.5">
              {PRIMARY.map((item) => {
                const Icon = item.icon;
                const isOn = active(item.to, "exact" in item && item.exact);
                return (
                  <Link
                    key={item.to}
                    to={item.to}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "flex items-center gap-3 rounded-md px-3 py-2.5 text-sm",
                      isOn
                        ? "bg-gold/15 font-semibold text-gold"
                        : "text-paper/70 hover:bg-white/5 hover:text-paper",
                    )}
                  >
                    <Icon className="size-4 shrink-0" />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
            <p className="mt-6 px-3 pb-2 text-[10px] font-bold uppercase tracking-[0.18em] text-paper/40">
              Specialists
            </p>
            <nav className="flex flex-col gap-0.5 pb-6">
              {MODULES.filter((m) => m.id !== "guardian").map((m) => {
                const href = `/app/team/${m.id}`;
                return (
                  <Link
                    key={m.id}
                    to="/app/team/$module"
                    params={{ module: m.id }}
                    onClick={() => setOpen(false)}
                    className={cn(
                      "rounded-md px-3 py-2 text-sm",
                      pathname === href
                        ? "bg-gold/15 font-semibold text-gold"
                        : "text-paper/65 hover:bg-white/5 hover:text-paper",
                    )}
                  >
                    {m.short}
                  </Link>
                );
              })}
            </nav>
          </div>
          <div className="border-t border-white/10 px-4 py-3 text-[10px] uppercase tracking-[0.16em] text-paper/40">
            {companyName}
          </div>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 flex h-[70px] items-center justify-between gap-3 border-b border-[#e4ddd0] bg-white px-4 md:px-6">
            <div className="flex min-w-0 flex-1 items-center gap-3">
              <button
                type="button"
                className="grid size-11 place-items-center rounded-md border border-[#e4ddd0] md:hidden"
                aria-label="Open menu"
                onClick={() => setOpen(true)}
              >
                <Menu className="size-5" />
              </button>
              <form
                className="hidden max-w-md flex-1 sm:block"
                onSubmit={(e) => {
                  e.preventDefault();
                  void navigate({ to: "/app/crm" });
                }}
              >
                <label className="flex h-11 items-center gap-2 rounded-md border border-[#e4ddd0] bg-[#faf7f1] px-3">
                  <Search className="size-4 text-muted" />
                  <input
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="Search the workspace"
                    className="h-full w-full bg-transparent text-sm outline-none placeholder:text-muted"
                  />
                </label>
              </form>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <button
                  type="button"
                  className="grid size-11 place-items-center rounded-md border border-[#e4ddd0]"
                  aria-label="Approvals"
                  onClick={() => setNotesOpen((v) => !v)}
                >
                  <Bell className="size-4" />
                  {pending.length > 0 && (
                    <span className="absolute right-1.5 top-1.5 size-2 rounded-full bg-gold" />
                  )}
                </button>
                {notesOpen && (
                  <div className="absolute right-0 top-12 w-80 rounded-md border border-[#e4ddd0] bg-white p-3 shadow-soft">
                    <p className="text-[10px] font-bold uppercase tracking-[0.16em] text-muted">
                      Pending approvals
                    </p>
                    {pending.length === 0 ? (
                      <p className="mt-2 text-sm text-muted">Nothing waiting.</p>
                    ) : (
                      <ul className="mt-2 divide-y divide-line">
                        {pending.slice(0, 5).map((a) => (
                          <li key={a.id} className="py-2 text-sm">
                            {a.summary}
                          </li>
                        ))}
                      </ul>
                    )}
                    <Link
                      to="/app/approvals"
                      className="mt-2 block text-xs font-bold uppercase tracking-wider text-warn"
                      onClick={() => setNotesOpen(false)}
                    >
                      Open approvals
                    </Link>
                  </div>
                )}
              </div>
              <div className="hidden text-right sm:block">
                <span className="block text-[10px] font-bold uppercase tracking-[0.14em] text-muted">
                  Signed in
                </span>
                <strong className="block max-w-[160px] truncate text-sm">{label}</strong>
              </div>
              <span className="grid size-10 place-items-center rounded-full bg-ink text-sm font-bold text-gold">
                {label.charAt(0).toUpperCase()}
              </span>
              <button
                type="button"
                disabled={signingOut}
                className="text-[10px] font-bold uppercase tracking-[0.12em] text-warn"
                onClick={() => {
                  setSigningOut(true);
                  void signOut().catch(() => setSigningOut(false));
                }}
              >
                {signingOut ? "Signing out" : "Sign out"}
              </button>
            </div>
          </header>
          <main className="min-w-0 flex-1 p-4 md:p-7">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  );
}
