import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { SignedIn, SignedOut } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Preloader } from "@/components/preloader";
import { GoldCursor } from "@/components/gold-cursor";
import { X } from "lucide-react";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/solutions", label: "Solutions" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function SiteHeader() {
  const { isPending } = useCurrentUserState();
  const [open, setOpen] = useState(false);

  return (
    <>
      <GoldCursor />
      <Preloader />
      <header className="absolute inset-x-0 top-0 z-40 text-paper">
        <div className="flex h-24 items-center justify-between px-5 md:px-16">
          <Link to="/" className="flex items-center">
            <img
              src="/brand/seal.png"
              alt="Caelomere"
              className="size-[58px] rounded-full object-cover"
              style={{ animation: "cae-spin 14s linear infinite" }}
            />
          </Link>
          <div className="flex items-center gap-4">
            {isPending ? null : (
              <>
                <SignedOut>
                  <Link
                    to="/login"
                    className="hidden rounded-full border border-gold/70 px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-gold sm:inline-flex"
                  >
                    Client login
                  </Link>
                </SignedOut>
                <SignedIn>
                  <Link
                    to="/app"
                    className="hidden rounded-full bg-gold px-5 py-2.5 text-[11px] font-semibold uppercase tracking-[0.16em] text-ink sm:inline-flex"
                  >
                    Open portal
                  </Link>
                </SignedIn>
              </>
            )}
            <button
              type="button"
              className="grid size-[60px] place-items-center rounded-full border-[2.5px] border-white bg-[#1a1a1a]"
              aria-label="Menu"
              onClick={() => setOpen(true)}
            >
              <span className="flex flex-col items-center gap-[5px]">
                <span className="block h-px w-5 bg-paper" />
                <span className="block h-px w-5 bg-paper" />
                <span className="block h-px w-3 bg-gold" />
              </span>
            </button>
          </div>
        </div>
      </header>

      {open && (
        <div className="fixed inset-0 z-50 bg-black/90 text-paper backdrop-blur-md">
          <div className="flex items-center justify-between px-6 py-6 md:px-16">
            <img
              src="/brand/seal.png"
              alt="Caelomere"
              className="size-14 rounded-full object-cover"
              style={{ animation: "cae-spin 14s linear infinite" }}
            />
            <button
              type="button"
              aria-label="Close"
              onClick={() => setOpen(false)}
              className="grid size-14 place-items-center rounded-full border border-white/40"
            >
              <X className="size-5" />
            </button>
          </div>
          <div className="grid gap-16 px-8 pt-8 md:grid-cols-[1fr_1.4fr] md:px-16">
            <div className="text-sm text-white/50">
              <p>Intelligence built for business</p>
              <a className="mt-3 block text-gold" href="mailto:hello@caelomere.com">
                hello@caelomere.com
              </a>
              <p className="mt-8 text-white/40">United Kingdom</p>
            </div>
            <nav className="flex flex-col gap-3">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setOpen(false)}
                  className="font-display text-5xl text-white/75 transition-colors hover:text-white md:text-6xl"
                >
                  {item.label}
                </Link>
              ))}
              <Link
                to="/login"
                onClick={() => setOpen(false)}
                className="mt-4 font-display text-4xl text-gold"
              >
                Client login
              </Link>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-white/10 bg-black px-5 py-16 text-paper/50 md:px-16">
      <div className="grid gap-10 md:grid-cols-3">
        <div className="flex items-start gap-4">
          <img
            src="/brand/seal.png"
            alt="Caelomere"
            className="size-[88px] rounded-full object-cover"
            style={{ animation: "cae-spin 18s linear infinite" }}
          />
          <p className="max-w-xs pt-2 text-sm leading-relaxed">
            Intelligence built for business. One operating layer for reception,
            customers, sales, documents and specialist work.
          </p>
        </div>
        <div className="text-sm leading-relaxed">
          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gold">Company</p>
          <p className="mt-3 text-paper">CAELOMERE</p>
          <p>United Kingdom</p>
          <a className="mt-2 block text-gold" href="mailto:hello@caelomere.com">
            hello@caelomere.com
          </a>
        </div>
        <div className="text-sm">
          <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-gold">Workspace</p>
          <div className="mt-3 flex flex-col gap-2">
            <Link to="/solutions" className="hover:text-gold">Solutions</Link>
            <Link to="/about" className="hover:text-gold">About</Link>
            <Link to="/contact" className="hover:text-gold">Contact</Link>
            <Link to="/lanterna" className="hover:text-gold">Studios</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
