import { useEffect, useState } from "react";

export function Preloader() {
  const [visible, setVisible] = useState(true);
  const [gone, setGone] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setVisible(false);
      setGone(true);
      return;
    }
    const hide = window.setTimeout(() => setVisible(false), 1800);
    const remove = window.setTimeout(() => setGone(true), 2300);
    return () => {
      window.clearTimeout(hide);
      window.clearTimeout(remove);
    };
  }, []);

  if (gone) return null;

  return (
    <div
      className="fixed inset-0 z-[80] grid place-items-center bg-black"
      style={{
        opacity: visible ? 1 : 0,
        pointerEvents: visible ? "auto" : "none",
        transition: "opacity 500ms ease",
      }}
      aria-hidden={!visible}
    >
      <video
        className="pointer-events-none absolute inset-0 h-full w-full object-cover opacity-35"
        src="/site/hero.mp4"
        autoPlay
        muted
        loop
        playsInline
      />
      <div className="absolute inset-0 bg-black/55" />
      <img
        src="/brand/seal.png"
        alt="Caelomere"
        width={200}
        height={200}
        className="relative z-10 size-[200px] rounded-full object-cover"
        style={{ animation: "cae-spin 8s linear infinite" }}
      />
    </div>
  );
}
