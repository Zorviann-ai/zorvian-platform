alter table campaigns add column if not exists title text;
alter table campaigns add column if not exists body text;
alter table campaigns add column if not exists goal text;
alter table campaigns add column if not exists content text;
alter table campaigns add column if not exists audience text;
update campaigns set title = coalesce(nullif(title, ''), nullif(goal, ''), 'Campaign') where title is null or title = '';
update campaigns set body = coalesce(nullif(body, ''), content, '') where body is null;

alter table approvals add column if not exists result text;
