create table if not exists workspaces (
  user_id text primary key,
  company_name text not null default 'My business',
  industry text not null default 'general',
  seeded boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists contacts (
  id text primary key,
  user_id text not null,
  name text not null,
  company text,
  email text,
  phone text,
  need text,
  source text not null default 'manual',
  score integer not null default 30,
  status text not null default 'new',
  created_at timestamptz not null default now()
);
create index if not exists contacts_user_id_idx on contacts (user_id, created_at desc);

create table if not exists tasks (
  id text primary key,
  user_id text not null,
  title text not null,
  owner text,
  due_date text,
  status text not null default 'open',
  priority text not null default 'normal',
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists tasks_user_id_idx on tasks (user_id, created_at desc);

create table if not exists bookings (
  id text primary key,
  user_id text not null,
  contact_name text not null,
  type text not null,
  date text not null,
  time text not null,
  notes text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);
create index if not exists bookings_user_id_idx on bookings (user_id, date);

create table if not exists documents (
  id text primary key,
  user_id text not null,
  type text not null,
  title text not null,
  body text not null,
  status text not null default 'draft',
  created_at timestamptz not null default now()
);
create index if not exists documents_user_id_idx on documents (user_id, created_at desc);

create table if not exists campaigns (
  id text primary key,
  user_id text not null,
  channel text not null,
  goal text not null,
  audience text,
  content text,
  status text not null default 'draft',
  created_at timestamptz not null default now()
);

create table if not exists routes (
  id text primary key,
  user_id text not null,
  operation text not null,
  vehicle text,
  start_point text,
  stops text,
  plan text,
  status text not null default 'draft',
  created_at timestamptz not null default now()
);

create table if not exists tenders (
  id text primary key,
  user_id text not null,
  title text not null,
  ref text,
  deadline text,
  value_note text,
  requirements text,
  analysis text,
  status text not null default 'review',
  created_at timestamptz not null default now()
);

create table if not exists opportunities (
  id text primary key,
  user_id text not null,
  kind text not null,
  title text not null,
  detail text,
  stage text not null default 'qualification',
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists opportunities_user_id_idx on opportunities (user_id, created_at desc);

create table if not exists audit_events (
  id text primary key,
  user_id text not null,
  event text not null,
  detail text,
  created_at timestamptz not null default now()
);
create index if not exists audit_events_user_id_idx on audit_events (user_id, created_at desc);

create table if not exists ai_runs (
  id text primary key,
  user_id text not null,
  tool text not null,
  prompt text not null,
  reply text not null,
  created_at timestamptz not null default now()
);
create index if not exists ai_runs_user_id_idx on ai_runs (user_id, created_at desc);
