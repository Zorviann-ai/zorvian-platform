alter table contacts add column if not exists company_id text;
alter table contacts add column if not exists tags text;
alter table contacts add column if not exists notes text;

create table if not exists companies (
  id text primary key,
  user_id text not null,
  name text not null,
  industry text,
  website text,
  phone text,
  email text,
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists companies_user_id_idx on companies (user_id, created_at desc);

create table if not exists deals (
  id text primary key,
  user_id text not null,
  title text not null,
  company_id text,
  contact_id text,
  stage text not null default 'lead',
  value_note text,
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists deals_user_id_idx on deals (user_id, created_at desc);

create table if not exists notes (
  id text primary key,
  user_id text not null,
  parent_type text not null,
  parent_id text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists notes_parent_idx on notes (user_id, parent_type, parent_id);

create table if not exists approvals (
  id text primary key,
  user_id text not null,
  agent text not null,
  action text not null,
  summary text not null,
  payload text,
  status text not null default 'pending',
  created_at timestamptz not null default now()
);
create index if not exists approvals_user_id_idx on approvals (user_id, created_at desc);

create table if not exists invoices (
  id text primary key,
  user_id text not null,
  contact_name text not null,
  reference text,
  amount_note text,
  due_date text,
  status text not null default 'draft',
  notes text,
  created_at timestamptz not null default now()
);
create index if not exists invoices_user_id_idx on invoices (user_id, created_at desc);

create table if not exists campaigns (
  id text primary key,
  user_id text not null,
  title text not null,
  channel text not null,
  body text not null,
  status text not null default 'draft',
  created_at timestamptz not null default now()
);
create index if not exists campaigns_user_id_idx on campaigns (user_id, created_at desc);
