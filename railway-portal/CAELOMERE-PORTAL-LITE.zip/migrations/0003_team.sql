create table if not exists handoffs (
  id text primary key,
  user_id text not null,
  from_agent text not null,
  to_agent text not null,
  subject text not null,
  body text,
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create index if not exists handoffs_user_id_idx on handoffs (user_id, created_at desc);

create table if not exists agent_messages (
  id text primary key,
  user_id text not null,
  agent text not null,
  role text not null,
  body text not null,
  created_at timestamptz not null default now()
);
create index if not exists agent_messages_user_idx on agent_messages (user_id, agent, created_at desc);

create table if not exists public_enquiries (
  id text primary key,
  name text not null,
  email text not null,
  company text,
  message text not null,
  created_at timestamptz not null default now()
);
