from pathlib import Path
import json
import re

raw = Path("/tmp/alice.txt").read_text(encoding="utf-8", errors="replace")
m = re.search(r"\nCHAPTER I\.\s+Down the Rabbit-Hole", raw)
if not m:
    m = re.search(r"CHAPTER I\.", raw)
text = raw[m.start() :]
foot = text.find("*** END OF")
if foot > 0:
    text = text[:foot]
parts = re.split(r"\n(?=CHAPTER [IVX]+\.)", text)
chapters = []
for p in parts:
    p = p.strip()
    if not p.startswith("CHAPTER"):
        continue
    lines = p.splitlines()
    title = re.sub(r"\s+", " ", " ".join(lines[:2])).strip()
    body = "\n".join(lines[2:]).strip()
    body = re.sub(r"\[Illustration\]", "", body)
    body = re.sub(r"\n{3,}", "\n\n", body).strip()
    paras = [x.strip() for x in re.split(r"\n\s*\n", body) if x.strip()]
    chapters.append(
        {
            "id": f"ch-{len(chapters) + 1}",
            "n": len(chapters) + 1,
            "title": title,
            "excerpt": " ".join(paras[0].split()[:70]) if paras else "",
            "paragraphs": paras[:28],
        }
    )

out = {
    "title": "Alice’s Adventures in Wonderland",
    "author": "Lewis Carroll",
    "year": 1865,
    "licence": "Public domain in the United Kingdom. Original 1865 text. Character designs follow the book, not any film studio.",
    "source": "Project Gutenberg ebook 11",
    "chapters": chapters,
}
dest = Path("/workspace/src/data/alice.json")
dest.parent.mkdir(exist_ok=True)
dest.write_text(json.dumps(out, indent=2, ensure_ascii=False))
print("chapters", len(chapters), "bytes", dest.stat().st_size)
for c in chapters:
    print(c["n"], c["title"])
