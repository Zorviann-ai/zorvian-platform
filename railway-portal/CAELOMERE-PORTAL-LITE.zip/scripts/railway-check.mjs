#!/usr/bin/env node
const required = ["DATABASE_URL", "BETTER_AUTH_SECRET", "BETTER_AUTH_URL"];
const missing = required.filter((key) => !process.env[key]?.trim());
if (missing.length) {
  console.error(`[railway] missing required environment variables: ${missing.join(", ")}`);
  process.exit(1);
}
if (!/^https:\/\//i.test(process.env.BETTER_AUTH_URL)) {
  console.error("[railway] BETTER_AUTH_URL must be the public https:// URL for the deployed service.");
  process.exit(1);
}
if (process.env.BETTER_AUTH_SECRET.length < 32) {
  console.error("[railway] BETTER_AUTH_SECRET must be at least 32 characters.");
  process.exit(1);
}
console.log("[railway] environment looks ready.");
