from pathlib import Path
import json
import re

raw = Path("/tmp/looking-glass.txt").read_text(encoding="utf-8", errors="replace")
starts = [m.start() for m in re.finditer(r"^CHAPTER I\.\s*$", raw, re.M)]
start = starts[-1] if starts else raw.find("CHAPTER I.")
text = raw[start:]
foot = text.find("*** END OF")
if foot > 0:
    text = text[:foot]
parts = re.split(r"\n(?=CHAPTER [IVX]+\.\s*\n)", text)
chapters = []
for p in parts:
    p = p.strip()
    if not p.startswith("CHAPTER"):
        continue
    lines = p.splitlines()
    title = re.sub(r"\s+", " ", " ".join(lines[:2])).strip()
    body = "\n".join(lines[2:]).strip()
    body = re.sub(r"\[Illustration\]", "", body)
    body = re.sub(r"\n{3,}", "\n\n", body).strip()
    paras = [x.strip() for x in re.split(r"\n\s*\n", body) if x.strip()]
    chapters.append(
        {
            "id": f"ch-{len(chapters) + 1}",
            "n": len(chapters) + 1,
            "title": title,
            "excerpt": " ".join(paras[0].split()[:70]) if paras else "",
            "paragraphs": paras[:28],
        }
    )

out = {
    "slug": "looking-glass",
    "title": "Through the Looking-Glass",
    "author": "Lewis Carroll",
    "year": 1871,
    "licence": "Public domain in the United Kingdom. Original 1871 text. Not affiliated with any film studio.",
    "source": "Project Gutenberg ebook 12",
    "chapters": chapters,
}
dest = Path("/workspace/src/data/looking-glass.json")
dest.write_text(json.dumps(out, indent=2, ensure_ascii=False))
print("chapters", len(chapters), dest.stat().st_size)
for c in chapters:
    print(c["n"], c["title"])
