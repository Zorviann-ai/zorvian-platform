#!/bin/sh
set -eu

export NODE_ENV="${NODE_ENV:-production}"
export NITRO_HOST="${NITRO_HOST:-0.0.0.0}"
export NITRO_PORT="${PORT:-${NITRO_PORT:-3000}}"

exec node .output/server/index.mjs
