# CAELOMERE Railway readiness status

Prepared from the uploaded `CAELOMERE-FULL-BUILD (5).zip`.

## Completed in this package

- Production Nitro preset changed from Vercel to `node-server`.
- Multi-stage Node 22 Dockerfile added.
- Railway config-as-code added.
- Railway pre-deploy database migration configured.
- Production start script binds Nitro to Railway's injected `PORT` on `0.0.0.0`.
- `/api/health` added; it returns HTTP 200 only when the app can query its database.
- PostgreSQL production path preserved through `DATABASE_URL`.
- Better Auth production URL/secret variables documented.
- Email/password authentication preserved for self-hosted Railway.
- Grok preview OAuth is no longer silently selected on a normal self-hosted deployment.
- xAI remains optional for base portal/database operation and required for live AI features.
- Library Visualisation routes remain `/lanterna`, `/lanterna/alice`, `/lanterna/looking-glass`.

## Local verification completed here

- `package.json` and `package-lock.json` parse successfully.
- production start shell script syntax passes `sh -n`.
- Railway environment validator passes with valid-shaped required variables.
- required application source, migrations and Library assets are present.

## Verification still requires Railway

This environment could not complete `npm ci` within its network execution window, so the final production image build and HTTP/browser smoke test must run in Railway's build environment. The included Dockerfile makes that build deterministic. Railway should not promote the deployment until `/api/health` returns HTTP 200.
