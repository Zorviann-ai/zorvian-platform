# CAELOMERE Portal — Railway deployment

This project is prepared to run as a normal Node service on Railway.

## Railway configuration already included

- Build: Railway detects the included multi-stage `Dockerfile` and runs `npm ci` + `npm run build`
- Production server: Nitro `node-server` (`.output/server/index.mjs`)
- Start command inside the image: `npm run start:server`
- Database migration: Railway runs `npm run db:migrate` as a pre-deploy command before traffic can move
- Health check: `GET /api/health`
- Health check requires a working database connection and returns HTTP 200 only when DB query succeeds

## Required Railway services

1. One Railway service containing this application.
2. One Railway PostgreSQL database in the same project.

## Required environment variables

### DATABASE_URL
Use the Railway PostgreSQL reference variable. Do not type a password into the source tree.

Example reference:
`DATABASE_URL=${{Postgres.DATABASE_URL}}`

If the database service has a different Railway service name, use that name in the reference.

### BETTER_AUTH_SECRET
A long random application secret, minimum 32 characters. Store only in Railway Variables.

### BETTER_AUTH_URL
The exact public HTTPS origin of the portal, with no trailing route.

First deploy example:
`https://your-service.up.railway.app`

Final production value:
`https://app.caelomere.com`

### VITE_AUTH_ENABLED
Set to:
`true`

Local email/password login is already enabled in the source.

### VITE_GROK_OAUTH_ENABLED
Set to `false` for the normal Railway email/password login. Only set `true` when Grok OAuth broker credentials are deliberately configured.

### XAI_API_KEY
Optional for the basic portal/database flow. Required for live CAELOMERE AI and speech features using xAI.

## Deployment sequence

1. Create Railway project from this source repository/archive.
2. Add a PostgreSQL database to the project.
3. Set `DATABASE_URL`, `BETTER_AUTH_SECRET`, `BETTER_AUTH_URL`, and `VITE_AUTH_ENABLED=true`.
4. Deploy.
5. Railway builds the included Dockerfile.
6. Railway runs the database migration as the pre-deploy command. If migration fails, deployment stops.
7. Railway starts the Nitro Node server and checks `/api/health`.
8. When healthy, open `/login`, create an account, then open `/app` and `/lanterna`.
9. After attaching `app.caelomere.com`, change `BETTER_AUTH_URL` to `https://app.caelomere.com` and redeploy once.

## Routes to verify

- `/` public CAELOMERE site
- `/login` client login / account creation
- `/app` signed-in Core portal
- `/lanterna` Library Visualisation
- `/api/health` service + database health

## Database behaviour

Production uses PostgreSQL whenever `DATABASE_URL` is present. The embedded PGLite fallback is only for local/preview use. The start command runs `npm run db:migrate` before serving traffic, and migrations are idempotent through the `_migrations` table.

## Important

Do not use the old One.com HTML as the application host. One.com can be removed after the Railway app, domain, login, portal, Library, and email/DNS dependencies have been verified.
